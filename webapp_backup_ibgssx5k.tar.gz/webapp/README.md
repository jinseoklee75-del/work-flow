# TeamFlow - 통합 업무공유 시스템

## 프로젝트 개요
- **제품명**: TeamFlow
- **목적**: 팀 내 Task/Schedule/Issue를 하나의 플랫폼에서 통합 관리하는 웹 기반 협업 시스템
- **플랫폼**: Cloudflare Pages + D1 Database (Edge 환경)
- **기술 스택**: Hono (TypeScript) + Cloudflare D1 + TailwindCSS + Chart.js

## 접속 URL
- **서비스**: http://localhost:3000 (로컬 개발)
- **테스트 계정**:
  - `minjun@teamflow.dev` / `password123` (관리자)
  - `seoyeon@teamflow.dev` / `password123`
  - `doyun@teamflow.dev` / `password123`
  - `jiwoo@teamflow.dev` / `password123`
  - `haeun@teamflow.dev` / `password123`

## 구현된 기능

### Phase 1 (완료)
- ✅ **로그인/로그아웃** - 세션 기반 인증
- ✅ **대시보드** - KPI 카드, 상태/우선순위 차트, 위험 업무, 지연 업무, 주요 이슈
- ✅ **업무 관리** - 생성/수정/삭제, 리스트 뷰, 칸반 보드, 필터/검색
- ✅ **일정 관리** - 월/주 캘린더, 일정 추가/수정/삭제, 중복 경고, 업무 자동 일정 생성
- ✅ **이슈 관리** - 생성/수정/삭제, 상태 변경, 필터, 미해결 이슈 강조
- ✅ **업무 상세** - 상세 정보 조회/수정, 상태 변경

### Phase 2 (완료)
- ✅ **댓글** - 업무별 댓글 작성/조회
- ✅ **파일 첨부** - 업무별 파일 업로드/관리
- ✅ **변경 이력** - 주요 변경 Activity Log 자동 기록

## 핵심 비즈니스 룰
- 업무에 마감일이 있으면 캘린더에 업무 일정 자동 생성
- 현재 시간 > 마감일이고 상태 != Done이면 지연 업무
- 마감 3일 이내 업무/일정은 강조 표시
- 일정 중복 시 경고 메시지 표시 (저장은 허용)
- 선행 업무 미완료 시 후속 업무에 차단 표시
- 소프트 삭제 적용 (deleted_at)

## 데이터 모델
| 엔티티 | 주요 필드 |
|--------|-----------|
| User | user_id, name, email, role, avatar_color |
| Task | task_id, title, status, priority, due_date, dependency_task_id |
| Schedule | schedule_id, title, type, start_date, end_date, related_task_id |
| Issue | issue_id, title, status, priority, task_id |
| Comment | comment_id, task_id, content |
| Attachment | attachment_id, task_id, file_name, file_url |
| ActivityLog | log_id, entity_type, entity_id, action, before_value, after_value |

## 주요 API 엔드포인트
```
POST   /api/auth/login
POST   /api/auth/logout
GET    /api/auth/me
GET    /api/users
GET    /api/tasks
POST   /api/tasks
GET    /api/tasks/:id
PUT    /api/tasks/:id
DELETE /api/tasks/:id
PATCH  /api/tasks/:id/status
GET    /api/schedules
POST   /api/schedules
GET    /api/issues
POST   /api/issues
PATCH  /api/issues/:id/status
GET    /api/tasks/:id/comments
POST   /api/tasks/:id/comments
POST   /api/tasks/:id/attachments
GET    /api/dashboard/summary
GET    /api/dashboard/risks
GET    /api/tasks/:id/activity-logs
```

## 개발 가이드

### 로컬 실행
```bash
npm run build
pm2 start ecosystem.config.cjs
```

### DB 초기화
```bash
npm run db:reset  # 마이그레이션 + 시드 데이터
```

### DB 마이그레이션만
```bash
npm run db:migrate:local
npm run db:seed
```

## Phase 3 예정 (미구현)
- 알림 시스템 (인앱/이메일)
- 주간 리포트 자동 생성
- 권한 세분화 (Admin/Member/Viewer)
- 외부 캘린더 연동

## 배포 상태
- **플랫폼**: Cloudflare Pages (준비 완료)
- **로컬 상태**: ✅ 운영 중 (포트 3000)
- **최종 업데이트**: 2026-03-31
