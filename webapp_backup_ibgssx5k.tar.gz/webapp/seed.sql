-- TeamFlow 시드 데이터

-- 샘플 사용자 (비밀번호는 모두 'password123' → SHA-256 해시)
INSERT OR IGNORE INTO users (user_id, name, email, password_hash, role, avatar_color) VALUES
  ('user-001', '김민준', 'minjun@teamflow.dev', 'ef92b778bafe771207e0abff7ef328b3f2d8a90a94f8a89e7e38e7e38e7e38e7', 'Admin', '#6366f1'),
  ('user-002', '이서연', 'seoyeon@teamflow.dev', 'ef92b778bafe771207e0abff7ef328b3f2d8a90a94f8a89e7e38e7e38e7e38e7', 'Member', '#ec4899'),
  ('user-003', '박도윤', 'doyun@teamflow.dev', 'ef92b778bafe771207e0abff7ef328b3f2d8a90a94f8a89e7e38e7e38e7e38e7', 'Member', '#f59e0b'),
  ('user-004', '최지우', 'jiwoo@teamflow.dev', 'ef92b778bafe771207e0abff7ef328b3f2d8a90a94f8a89e7e38e7e38e7e38e7', 'Member', '#10b981'),
  ('user-005', '정하은', 'haeun@teamflow.dev', 'ef92b778bafe771207e0abff7ef328b3f2d8a90a94f8a89e7e38e7e38e7e38e7', 'Member', '#3b82f6');

-- 샘플 업무
INSERT OR IGNORE INTO tasks (task_id, title, description, assignee_id, status, priority, due_date, created_by, created_at, updated_at) VALUES
  ('task-001', '신규 랜딩페이지 디자인', '마케팅팀 요청에 따른 신규 랜딩페이지 UI/UX 디자인 작업', 'user-002', 'In Progress', 'High', '2026-04-10 18:00:00', 'user-001', datetime('now', '-10 days'), datetime('now', '-2 days')),
  ('task-002', 'API 성능 최적화', '주요 조회 API 응답시간 2초 이내로 개선', 'user-003', 'To-do', 'High', '2026-04-15 18:00:00', 'user-001', datetime('now', '-8 days'), datetime('now', '-1 days')),
  ('task-003', '사용자 인증 모듈 개선', 'JWT 기반 인증 로직 리팩토링 및 세션 관리 개선', 'user-003', 'Done', 'Medium', '2026-03-25 18:00:00', 'user-001', datetime('now', '-15 days'), datetime('now', '-3 days')),
  ('task-004', '주간 리포트 자동화', '매주 금요일 업무 현황 자동 집계 및 리포트 발송 기능 개발', 'user-004', 'To-do', 'Medium', '2026-04-20 18:00:00', 'user-002', datetime('now', '-5 days'), datetime('now', '-5 days')),
  ('task-005', '데이터베이스 마이그레이션', '운영 DB를 신규 서버로 마이그레이션', 'user-001', 'In Progress', 'High', '2026-03-28 18:00:00', 'user-001', datetime('now', '-12 days'), datetime('now')),
  ('task-006', '모바일 반응형 UI 적용', '기존 대시보드에 모바일 반응형 CSS 적용', 'user-002', 'To-do', 'Low', '2026-04-25 18:00:00', 'user-002', datetime('now', '-3 days'), datetime('now', '-3 days')),
  ('task-007', 'CI/CD 파이프라인 구축', 'GitHub Actions 기반 자동 배포 파이프라인 설정', 'user-005', 'In Progress', 'Medium', '2026-04-05 18:00:00', 'user-001', datetime('now', '-7 days'), datetime('now', '-1 days')),
  ('task-008', '보안 취약점 점검', '전체 시스템 보안 취약점 스캔 및 패치', 'user-005', 'To-do', 'High', '2026-03-29 18:00:00', 'user-001', datetime('now', '-4 days'), datetime('now', '-4 days')),
  ('task-009', '고객 피드백 분석', '최근 1개월 고객 피드백 수집 및 분석 보고서 작성', 'user-004', 'Done', 'Low', '2026-03-20 18:00:00', 'user-002', datetime('now', '-20 days'), datetime('now', '-5 days')),
  ('task-010', '코드 리뷰 프로세스 정립', '팀 내 코드 리뷰 가이드라인 작성 및 공유', 'user-003', 'To-do', 'Low', '2026-04-30 18:00:00', 'user-003', datetime('now', '-2 days'), datetime('now', '-2 days'));

-- 업무 의존성 설정
UPDATE tasks SET dependency_task_id = 'task-003' WHERE task_id = 'task-002';
UPDATE tasks SET dependency_task_id = 'task-005' WHERE task_id = 'task-004';

-- 지연 업무 업데이트
UPDATE tasks SET is_delayed = 1 WHERE task_id IN ('task-005', 'task-008') AND status != 'Done';

-- 샘플 일정
INSERT OR IGNORE INTO schedules (schedule_id, title, type, start_date, end_date, related_task_id, owner_id, description, created_by) VALUES
  ('sch-001', '주간 팀 미팅', 'meeting', '2026-04-01 10:00:00', '2026-04-01 11:00:00', NULL, 'user-001', '매주 화요일 정기 팀 미팅', 'user-001'),
  ('sch-002', '신규 랜딩페이지 디자인 마감', 'task', '2026-04-10 18:00:00', '2026-04-10 18:00:00', 'task-001', 'user-002', '업무 자동 생성 일정', 'user-002'),
  ('sch-003', 'API 성능 최적화 마감', 'task', '2026-04-15 18:00:00', '2026-04-15 18:00:00', 'task-002', 'user-003', '업무 자동 생성 일정', 'user-003'),
  ('sch-004', '제주 고객사 출장', 'business_trip', '2026-04-07 09:00:00', '2026-04-08 18:00:00', NULL, 'user-001', '제주 파트너사 방문 미팅', 'user-001'),
  ('sch-005', '개발팀 워크샵', 'meeting', '2026-04-14 13:00:00', '2026-04-14 17:00:00', NULL, 'user-003', '상반기 기술 스택 논의', 'user-003'),
  ('sch-006', '연차 휴가', 'vacation', '2026-04-17 00:00:00', '2026-04-18 23:59:00', NULL, 'user-002', '', 'user-002'),
  ('sch-007', 'CI/CD 마감', 'task', '2026-04-05 18:00:00', '2026-04-05 18:00:00', 'task-007', 'user-005', '업무 자동 생성 일정', 'user-005'),
  ('sch-008', '외근 - 클라이언트 미팅', 'out_of_office', '2026-04-03 14:00:00', '2026-04-03 17:00:00', NULL, 'user-004', '강남 클라이언트 사무소 방문', 'user-004');

-- 샘플 이슈
INSERT OR IGNORE INTO issues (issue_id, title, description, task_id, status, priority, created_by) VALUES
  ('issue-001', '로그인 페이지 모바일 깨짐', 'iPhone 14에서 로그인 폼 레이아웃이 깨지는 현상 발생', 'task-001', 'Open', 'High', 'user-002'),
  ('issue-002', 'API 타임아웃 오류', '대용량 데이터 조회 시 30초 이상 응답 없음', 'task-002', 'In Progress', 'Critical', 'user-003'),
  ('issue-003', '파일 업로드 실패', '10MB 이상 파일 업로드 시 500 에러', NULL, 'Open', 'Medium', 'user-004'),
  ('issue-004', '캘린더 일정 중복 표시', '동일 일정이 2번 렌더링 되는 버그', NULL, 'Resolved', 'Low', 'user-001'),
  ('issue-005', '데이터베이스 마이그레이션 오류', '특정 테이블 컬럼 타입 불일치로 마이그레이션 실패', 'task-005', 'In Progress', 'Critical', 'user-001'),
  ('issue-006', '이메일 알림 미발송', '업무 할당 시 이메일 알림이 발송되지 않음', NULL, 'Open', 'Medium', 'user-002');

-- 샘플 댓글
INSERT OR IGNORE INTO comments (comment_id, task_id, user_id, content, created_at) VALUES
  ('cmt-001', 'task-001', 'user-001', '디자인 초안 확인했습니다. 헤더 섹션 수정 요청드립니다.', datetime('now', '-5 days')),
  ('cmt-002', 'task-001', 'user-002', '네, 오늘 오후까지 수정해서 다시 공유드리겠습니다.', datetime('now', '-4 days')),
  ('cmt-003', 'task-001', 'user-003', '색상 톤을 브랜드 가이드라인에 맞춰 조정해주세요.', datetime('now', '-3 days')),
  ('cmt-004', 'task-002', 'user-003', 'N+1 쿼리 문제가 주요 병목으로 확인됨. 인덱스 추가 작업 중입니다.', datetime('now', '-2 days')),
  ('cmt-005', 'task-005', 'user-001', '스테이징 환경에서 먼저 테스트 진행 후 운영 적용 예정입니다.', datetime('now', '-1 days')),
  ('cmt-006', 'task-007', 'user-005', 'GitHub Actions 워크플로우 초안 작성 완료. 리뷰 부탁드립니다.', datetime('now', '-1 days'));

-- 샘플 활동 로그
INSERT OR IGNORE INTO activity_logs (log_id, entity_type, entity_id, action, before_value, after_value, acted_by, created_at) VALUES
  ('log-001', 'task', 'task-001', 'create', NULL, '{"title":"신규 랜딩페이지 디자인","status":"To-do"}', 'user-001', datetime('now', '-10 days')),
  ('log-002', 'task', 'task-001', 'status_change', '{"status":"To-do"}', '{"status":"In Progress"}', 'user-002', datetime('now', '-8 days')),
  ('log-003', 'task', 'task-001', 'assign', '{"assignee_id":null}', '{"assignee_id":"user-002"}', 'user-001', datetime('now', '-10 days')),
  ('log-004', 'task', 'task-003', 'status_change', '{"status":"In Progress"}', '{"status":"Done"}', 'user-003', datetime('now', '-3 days')),
  ('log-005', 'issue', 'issue-001', 'create', NULL, '{"title":"로그인 페이지 모바일 깨짐","status":"Open"}', 'user-002', datetime('now', '-5 days')),
  ('log-006', 'task', 'task-005', 'status_change', '{"status":"To-do"}', '{"status":"In Progress"}', 'user-001', datetime('now', '-6 days')),
  ('log-007', 'schedule', 'sch-001', 'create', NULL, '{"title":"주간 팀 미팅"}', 'user-001', datetime('now', '-7 days')),
  ('log-008', 'task', 'task-002', 'update', '{"priority":"Medium"}', '{"priority":"High"}', 'user-001', datetime('now', '-3 days'));
