import { defineConfig } from 'vite'
import pages from '@hono/vite-cloudflare-pages'

export default defineConfig(({ mode }) => {
  if (mode === 'client') {
    return {
      build: {
        outDir: './dist/static',
        rollupOptions: {
          input: './src/client.ts',
        }
      }
    }
  }
  return {
    plugins: [pages()],
    build: {
      outDir: 'dist',
    }
  }
})
