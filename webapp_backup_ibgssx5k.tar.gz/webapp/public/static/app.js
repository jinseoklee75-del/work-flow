// TeamFlow - Main App (로그인 제거 버전)
dayjs.locale('ko');

// ===== Global State =====
const App = {
  currentUser: null,
  currentPage: 'dashboard',
  users: [],
  tasks: [],
  schedules: [],
  issues: [],
  currentTaskId: null,
  calendarDate: dayjs(),
  calendarView: 'month',
  taskView: 'list',
  taskFilter: { status: '', priority: '', assignee_id: '', search: '' },
  issueFilter: { status: '', priority: '' },
  dashboardData: null,
};

// ===== API Client =====
const api = {
  base: '/api',
  getHeaders() {
    const headers = { 'Content-Type': 'application/json' };
    if (App.currentUser?.user_id) {
      headers['X-User-Id'] = App.currentUser.user_id;
    }
    return headers;
  },
  async request(method, url, data) {
    try {
      const res = await axios({
        method,
        url: this.base + url,
        data,
        headers: this.getHeaders(),
        withCredentials: false,
      });
      return { data: res.data, ok: true };
    } catch (e) {
      const msg = e.response?.data?.error || '요청 처리 중 오류가 발생했습니다.';
      return { error: msg, ok: false };
    }
  },
  get: (url) => api.request('GET', url),
  post: (url, data) => api.request('POST', url, data),
  put: (url, data) => api.request('PUT', url, data),
  patch: (url, data) => api.request('PATCH', url, data),
  delete: (url) => api.request('DELETE', url),
};

// ===== Toast =====
function toast(message, type = 'info') {
  const container = document.getElementById('toast-container') || (() => {
    const c = document.createElement('div');
    c.id = 'toast-container';
    c.className = 'toast-container';
    document.body.appendChild(c);
    return c;
  })();
  const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.innerHTML = `<i class="fas ${icons[type]}"></i>${message}`;
  container.appendChild(t);
  setTimeout(() => { t.style.animation = 'fadeOut 0.3s ease forwards'; setTimeout(() => t.remove(), 300); }, 3000);
}

// ===== Modal =====
function showModal(html, onClose) {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `<div class="modal">${html}</div>`;
  overlay.addEventListener('click', (e) => { if (e.target === overlay) { overlay.remove(); onClose?.(); } });
  document.body.appendChild(overlay);
  overlay.querySelector('.modal').addEventListener('click', e => e.stopPropagation());
  return overlay;
}
function closeModal() {
  document.querySelector('.modal-overlay')?.remove();
}

// ===== Utils =====
function statusBadge(status) {
  const map = { 'To-do': 'badge-todo', 'In Progress': 'badge-inprogress', 'Done': 'badge-done', 'Open': 'badge-open', 'Resolved': 'badge-resolved' };
  return `<span class="badge ${map[status] || 'badge-todo'}">${status}</span>`;
}
function priorityBadge(p) {
  const map = { 'Low': 'badge-low', 'Medium': 'badge-medium', 'High': 'badge-high', 'Critical': 'badge-critical' };
  return `<span class="badge ${map[p] || 'badge-medium'}">${p}</span>`;
}
function avatarHtml(name, color, size = '') {
  const initial = name ? name.charAt(0) : '?';
  return `<div class="avatar ${size}" style="background:${color || '#6366f1'}">${initial}</div>`;
}
function formatDate(d) { return d ? dayjs(d).format('YYYY.MM.DD') : '-'; }
function formatDateTime(d) { return d ? dayjs(d).format('YYYY.MM.DD HH:mm') : '-'; }
function isDelayed(dueDate, status) { return dueDate && status !== 'Done' && new Date() > new Date(dueDate); }
function dueSoonWarning(dueDate, status) {
  if (!dueDate || status === 'Done') return false;
  const d = new Date(dueDate);
  const now = new Date();
  const diff = (d - now) / (1000 * 60 * 60 * 24);
  return diff >= 0 && diff <= 3;
}
function escHtml(str) { return str ? str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;') : ''; }

// ===== Router =====
function navigate(page, params = {}) {
  App.currentPage = page;
  if (params.taskId) App.currentTaskId = params.taskId;
  render();
}

function render() {
  const root = document.getElementById('app');
  // 로그인 없이 바로 레이아웃 표시
  root.innerHTML = renderLayout();
  bindLayoutEvents();
  renderPage();
}

// ===== Layout =====
function renderLayout() {
  const pages = [
    { id: 'dashboard', icon: 'fa-chart-pie', label: '대시보드' },
    { id: 'tasks', icon: 'fa-tasks', label: '업무 관리' },
    { id: 'schedules', icon: 'fa-calendar-alt', label: '일정 관리' },
    { id: 'issues', icon: 'fa-exclamation-triangle', label: '이슈 관리' },
    { id: 'members', icon: 'fa-users-cog', label: '회원 관리' },
  ];
  const navHtml = pages.map(p => `
    <a class="sidebar-item ${App.currentPage === p.id || (App.currentPage === 'task-detail' && p.id === 'tasks') ? 'active' : ''}" data-page="${p.id}">
      <i class="fas ${p.icon}"></i>${p.label}
    </a>`).join('');

  const u = App.currentUser;
  const userSwitcherHtml = u ? `
    <div class="user-switcher">
      <div style="font-size:10px;color:rgba(255,255,255,0.4);margin-bottom:6px;padding:0 4px;letter-spacing:0.5px">현재 사용자</div>
      <div class="user-info" style="cursor:pointer" id="user-switcher-trigger">
        ${avatarHtml(u.name, u.avatar_color)}
        <div style="flex:1;min-width:0">
          <div style="font-size:13px;font-weight:600;color:white;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escHtml(u.name)}</div>
          <div style="font-size:11px;color:rgba(255,255,255,0.5)">${escHtml(u.role || 'Member')}</div>
        </div>
        <i class="fas fa-exchange-alt" style="color:rgba(255,255,255,0.4);font-size:12px"></i>
      </div>
    </div>` : `
    <div class="user-switcher">
      <div style="font-size:12px;color:rgba(255,255,255,0.5);text-align:center;padding:8px">사용자 없음</div>
    </div>`;

  return `
  <div class="app-layout">
    <nav class="sidebar" id="sidebar">
      <div class="sidebar-logo">
        <h1><i class="fas fa-layer-group"></i> TeamFlow</h1>
        <span>통합 업무공유 시스템</span>
      </div>
      <div class="sidebar-nav">
        <div class="sidebar-section">메뉴</div>
        ${navHtml}
      </div>
      <div class="sidebar-footer">
        ${userSwitcherHtml}
      </div>
    </nav>
    <div class="main-content">
      <header class="top-header">
        <div style="display:flex;align-items:center;gap:12px">
          <button class="btn-icon btn-ghost" id="sidebar-toggle" style="display:none"><i class="fas fa-bars"></i></button>
          <h2 id="page-title" style="font-size:18px;font-weight:700;margin:0"></h2>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <span style="font-size:13px;color:#64748b">${formatDate(new Date())}</span>
        </div>
      </header>
      <div class="page-content" id="page-content"></div>
    </div>
  </div>
  <div id="toast-container" class="toast-container"></div>`;
}

function bindLayoutEvents() {
  document.querySelectorAll('[data-page]').forEach(el => {
    el.addEventListener('click', () => navigate(el.dataset.page));
  });
  // 사용자 전환 트리거
  const switcher = document.getElementById('user-switcher-trigger');
  if (switcher) {
    switcher.addEventListener('click', () => showUserSwitcherModal());
  }
}

// ===== User Switcher Modal =====
function showUserSwitcherModal() {
  if (!App.users.length) {
    toast('등록된 팀원이 없습니다. 회원 관리에서 추가하세요.', 'warning');
    return;
  }
  const html = `
  <div class="modal-header">
    <div class="modal-title"><i class="fas fa-exchange-alt"></i> 사용자 전환</div>
    <button class="btn-icon btn-ghost" onclick="closeModal()"><i class="fas fa-times"></i></button>
  </div>
  <div class="modal-body" style="padding:8px 0">
    <p style="font-size:13px;color:#64748b;padding:0 20px 12px">현재 작업할 사용자를 선택하세요.</p>
    <div id="user-switch-list">
      ${App.users.map(u => `
        <div class="user-switch-item ${App.currentUser?.user_id === u.user_id ? 'active' : ''}" data-uid="${u.user_id}" style="display:flex;align-items:center;gap:12px;padding:10px 20px;cursor:pointer;transition:background 0.15s;${App.currentUser?.user_id === u.user_id ? 'background:#f0f4ff;' : ''}">
          ${avatarHtml(u.name, u.avatar_color)}
          <div style="flex:1">
            <div style="font-size:14px;font-weight:500">${escHtml(u.name)}</div>
            <div style="font-size:12px;color:#64748b">${escHtml(u.email)} · ${escHtml(u.role||'Member')}</div>
          </div>
          ${App.currentUser?.user_id === u.user_id ? '<i class="fas fa-check" style="color:#6366f1"></i>' : ''}
        </div>`).join('')}
    </div>
  </div>
  <div class="modal-footer">
    <button class="btn btn-secondary" onclick="closeModal()">닫기</button>
  </div>`;

  showModal(html);
  document.querySelectorAll('.user-switch-item').forEach(el => {
    el.addEventListener('mouseenter', () => { if (!el.classList.contains('active')) el.style.background = '#f8fafc'; });
    el.addEventListener('mouseleave', () => { if (!el.classList.contains('active')) el.style.background = ''; });
    el.addEventListener('click', () => {
      const uid = el.dataset.uid;
      const user = App.users.find(u => u.user_id === uid);
      if (user && user.user_id !== App.currentUser?.user_id) {
        App.currentUser = user;
        // localStorage에 저장
        try { localStorage.setItem('tf_current_user_id', user.user_id); } catch(e) {}
        toast(`${user.name}으로 전환되었습니다.`, 'success');
        closeModal();
        render();
      } else {
        closeModal();
      }
    });
  });
}

async function loadInitialData() {
  const [usersR, tasksR, schedulesR, issuesR] = await Promise.all([
    api.get('/users'),
    api.get('/tasks'),
    api.get('/schedules'),
    api.get('/issues'),
  ]);
  App.users = usersR.ok ? usersR.data.users : [];
  App.tasks = tasksR.ok ? tasksR.data.tasks : [];
  App.schedules = schedulesR.ok ? schedulesR.data.schedules : [];
  App.issues = issuesR.ok ? issuesR.data.issues : [];
}

// ===== Page Renderer =====
function renderPage() {
  const titles = {
    dashboard: '대시보드',
    tasks: '업무 관리',
    schedules: '일정 관리',
    issues: '이슈 관리',
    members: '회원 관리',
    'task-detail': '업무 상세',
  };
  document.getElementById('page-title').textContent = titles[App.currentPage] || '';

  switch (App.currentPage) {
    case 'dashboard': renderDashboard(); break;
    case 'tasks': renderTasksPage(); break;
    case 'schedules': renderSchedulesPage(); break;
    case 'issues': renderIssuesPage(); break;
    case 'members': renderMembersPage(); break;
    case 'task-detail': renderTaskDetail(); break;
  }
}

// ===== Dashboard Page =====
async function renderDashboard() {
  const content = document.getElementById('page-content');
  content.innerHTML = '<div class="loading-overlay"><div class="spinner" style="width:36px;height:36px;border-width:3px"></div></div>';

  const [sumR, riskR] = await Promise.all([api.get('/dashboard/summary'), api.get('/dashboard/risks')]);
  if (!sumR.ok) { toast('대시보드 데이터를 불러오지 못했습니다.', 'error'); return; }

  const s = sumR.data.summary;
  const risks = riskR.ok ? riskR.data.risks : {};

  const tasksR = await api.get('/tasks');
  if (tasksR.ok) App.tasks = tasksR.data.tasks;

  content.innerHTML = `
  <div style="display:flex;flex-direction:column;gap:20px">
    <!-- KPI Cards -->
    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-icon" style="background:#ede9fe"><i class="fas fa-clipboard-list" style="color:#6366f1"></i></div>
        <div class="kpi-value">${s.total}</div>
        <div class="kpi-label">전체 업무</div>
        <div class="kpi-trend" style="color:#64748b"><span style="color:#6366f1">${s.in_progress}</span> 진행중 · <span>${s.todo}</span> 예정</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-icon" style="background:#d1fae5"><i class="fas fa-check-circle" style="color:#10b981"></i></div>
        <div class="kpi-value" style="color:#10b981">${s.completion_rate}%</div>
        <div class="kpi-label">완료율</div>
        <div style="margin-top:8px"><div class="progress-bar"><div class="progress-fill" style="width:${s.completion_rate}%;background:#10b981"></div></div></div>
      </div>
      <div class="kpi-card">
        <div class="kpi-icon" style="background:#fee2e2"><i class="fas fa-clock" style="color:#ef4444"></i></div>
        <div class="kpi-value" style="color:#ef4444">${s.delayed}</div>
        <div class="kpi-label">지연 업무</div>
        <div class="kpi-trend" style="color:#64748b">지연률 <span style="color:#ef4444">${s.delay_rate}%</span></div>
      </div>
      <div class="kpi-card">
        <div class="kpi-icon" style="background:#fef9c3"><i class="fas fa-calendar-day" style="color:#f59e0b"></i></div>
        <div class="kpi-value" style="color:#f59e0b">${s.due_soon}</div>
        <div class="kpi-label">마감 임박 (3일)</div>
        <div class="kpi-trend" style="color:#64748b">주의 필요</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-icon" style="background:#fee2e2"><i class="fas fa-exclamation-circle" style="color:#ef4444"></i></div>
        <div class="kpi-value" style="color:#ef4444">${s.unresolved_issues}</div>
        <div class="kpi-label">미해결 이슈</div>
        <div class="kpi-trend" style="color:#64748b">Critical <span style="color:#dc2626">${s.critical_issues}</span>건</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-icon" style="background:#dbeafe"><i class="fas fa-users" style="color:#3b82f6"></i></div>
        <div class="kpi-value" style="color:#3b82f6">${App.users.length}</div>
        <div class="kpi-label">팀원 수</div>
        <div class="kpi-trend" style="color:#64748b">전체 팀원</div>
      </div>
    </div>

    <!-- Charts + Risk -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
      <div class="card">
        <div class="card-header"><span style="font-weight:600">업무 상태 분포</span></div>
        <div class="card-body" style="display:flex;align-items:center;justify-content:center;height:220px">
          <canvas id="statusChart" width="200" height="200" style="max-width:200px"></canvas>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><span style="font-weight:600">우선순위 분포</span></div>
        <div class="card-body" style="display:flex;align-items:center;justify-content:center;height:220px">
          <canvas id="priorityChart" width="200" height="200" style="max-width:200px"></canvas>
        </div>
      </div>
    </div>

    <!-- Risk + Delayed Tasks -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
      <div class="card">
        <div class="card-header">
          <span style="font-weight:600;display:flex;align-items:center;gap:8px"><i class="fas fa-fire text-red-500" style="color:#ef4444"></i> 위험 업무</span>
          <span class="badge badge-high">${(risks.overdue_tasks?.length||0) + (risks.critical_issue_tasks?.length||0) + (risks.blocked_tasks?.length||0)}건</span>
        </div>
        <div class="card-body" style="padding:12px;max-height:300px;overflow-y:auto">
          ${renderRiskItems(risks)}
        </div>
      </div>
      <div class="card">
        <div class="card-header">
          <span style="font-weight:600;display:flex;align-items:center;gap:8px"><i class="fas fa-clock" style="color:#f59e0b"></i> 지연 업무</span>
          <span class="badge badge-medium">${App.tasks.filter(t => isDelayed(t.due_date, t.status)).length}건</span>
        </div>
        <div class="card-body" style="padding:12px;max-height:300px;overflow-y:auto">
          ${renderDelayedTasks(App.tasks.filter(t => isDelayed(t.due_date, t.status)))}
        </div>
      </div>
    </div>

    <!-- Issues Table -->
    <div class="card">
      <div class="card-header">
        <span style="font-weight:600"><i class="fas fa-exclamation-triangle" style="color:#f59e0b"></i> 주요 이슈</span>
        <span class="badge badge-high">${App.issues.filter(i => i.status !== 'Resolved').length}건 미해결</span>
      </div>
      <div class="card-body" style="padding:0">
        ${renderDashboardIssues(App.issues.filter(i => i.status !== 'Resolved').slice(0,5))}
      </div>
    </div>
  </div>`;

  renderCharts(s);
}

function renderRiskItems(risks) {
  const items = [
    ...(risks.overdue_tasks||[]).map(t => ({ ...t, riskType: '지연', color: '#ef4444' })),
    ...(risks.critical_issue_tasks||[]).map(t => ({ ...t, riskType: 'Critical 이슈', color: '#dc2626' })),
    ...(risks.blocked_tasks||[]).map(t => ({ ...t, riskType: '차단됨', color: '#f59e0b' })),
  ];
  if (!items.length) return '<div class="empty-state" style="padding:30px"><i class="fas fa-shield-alt" style="color:#10b981;font-size:32px;margin-bottom:8px"></i><p>위험 업무 없음</p></div>';
  return items.slice(0,8).map(t => `
    <div style="display:flex;align-items:center;gap:10px;padding:10px;border-bottom:1px solid #f8fafc;cursor:pointer" onclick="navigate('task-detail',{taskId:'${t.task_id}'})">
      <span class="badge" style="background:${t.color}20;color:${t.color};white-space:nowrap">${t.riskType}</span>
      <div style="flex:1;min-width:0">
        <div style="font-size:13px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escHtml(t.title)}</div>
      </div>
      ${priorityBadge(t.priority)}
    </div>`).join('');
}

function renderDelayedTasks(tasks) {
  if (!tasks.length) return '<div class="empty-state" style="padding:30px"><i class="fas fa-check-circle" style="color:#10b981;font-size:32px;margin-bottom:8px"></i><p>지연된 업무가 없습니다</p></div>';
  return tasks.slice(0,8).map(t => `
    <div style="display:flex;align-items:center;gap:10px;padding:10px;border-bottom:1px solid #f8fafc;cursor:pointer" onclick="navigate('task-detail',{taskId:'${t.task_id}'})">
      <div style="flex:1;min-width:0">
        <div style="font-size:13px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escHtml(t.title)}</div>
        <div style="font-size:11px;color:#ef4444">마감: ${formatDate(t.due_date)}</div>
      </div>
      ${priorityBadge(t.priority)}
      ${t.assignee_name ? avatarHtml(t.assignee_name, t.assignee_color, 'avatar-sm') : ''}
    </div>`).join('');
}

function renderDashboardIssues(issues) {
  if (!issues.length) return '<div class="empty-state" style="padding:24px"><p>주요 이슈가 없습니다</p></div>';
  return `<table class="table">
    <thead><tr><th>제목</th><th>중요도</th><th>상태</th><th>관련 업무</th><th>등록자</th></tr></thead>
    <tbody>${issues.map(i => `
      <tr>
        <td style="font-size:13px;font-weight:500">${escHtml(i.title)}</td>
        <td>${priorityBadge(i.priority)}</td>
        <td>${statusBadge(i.status)}</td>
        <td style="font-size:12px;color:#64748b">${i.task_title ? escHtml(i.task_title) : '-'}</td>
        <td style="font-size:12px">${i.creator_name ? escHtml(i.creator_name) : '-'}</td>
      </tr>`).join('')}
    </tbody></table>`;
}

function renderCharts(s) {
  const sc = document.getElementById('statusChart');
  if (sc) {
    new Chart(sc, {
      type: 'doughnut',
      data: {
        labels: ['할 일', '진행중', '완료'],
        datasets: [{ data: [s.todo, s.in_progress, s.done], backgroundColor: ['#e2e8f0', '#3b82f6', '#10b981'], borderWidth: 0 }]
      },
      options: { plugins: { legend: { position: 'bottom', labels: { font: { size: 12 } } } }, cutout: '65%' }
    });
  }
  const pc = document.getElementById('priorityChart');
  if (pc) {
    const tasks = App.tasks.filter(t => !t.deleted_at);
    const counts = { Low: 0, Medium: 0, High: 0 };
    tasks.forEach(t => { if (counts[t.priority] !== undefined) counts[t.priority]++; });
    new Chart(pc, {
      type: 'bar',
      data: {
        labels: ['Low', 'Medium', 'High'],
        datasets: [{ data: [counts.Low, counts.Medium, counts.High], backgroundColor: ['#94a3b8', '#f59e0b', '#ef4444'], borderRadius: 6, borderWidth: 0 }]
      },
      options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
    });
  }
}

// ===== Tasks Page =====
function renderTasksPage() {
  const content = document.getElementById('page-content');
  content.innerHTML = `
  <div style="display:flex;flex-direction:column;gap:16px">
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
      <div class="filter-bar">
        <div class="search-box">
          <i class="fas fa-search"></i>
          <input class="form-control filter-select" id="task-search" placeholder="업무 검색..." value="${escHtml(App.taskFilter.search)}" style="width:200px">
        </div>
        <select class="filter-select" id="filter-status">
          <option value="">전체 상태</option>
          <option value="To-do" ${App.taskFilter.status==='To-do'?'selected':''}>To-do</option>
          <option value="In Progress" ${App.taskFilter.status==='In Progress'?'selected':''}>In Progress</option>
          <option value="Done" ${App.taskFilter.status==='Done'?'selected':''}>Done</option>
        </select>
        <select class="filter-select" id="filter-priority">
          <option value="">전체 우선순위</option>
          <option value="High" ${App.taskFilter.priority==='High'?'selected':''}>High</option>
          <option value="Medium" ${App.taskFilter.priority==='Medium'?'selected':''}>Medium</option>
          <option value="Low" ${App.taskFilter.priority==='Low'?'selected':''}>Low</option>
        </select>
        <select class="filter-select" id="filter-assignee">
          <option value="">전체 담당자</option>
          ${App.users.map(u => `<option value="${u.user_id}" ${App.taskFilter.assignee_id===u.user_id?'selected':''}>${escHtml(u.name)}</option>`).join('')}
        </select>
      </div>
      <div style="display:flex;gap:8px;align-items:center">
        <div class="view-toggle">
          <button class="view-btn ${App.taskView==='list'?'active':''}" id="view-list"><i class="fas fa-list"></i> 리스트</button>
          <button class="view-btn ${App.taskView==='kanban'?'active':''}" id="view-kanban"><i class="fas fa-columns"></i> 칸반</button>
        </div>
        <button class="btn btn-primary" id="btn-new-task"><i class="fas fa-plus"></i> 업무 추가</button>
      </div>
    </div>
    <div id="task-view-content"></div>
  </div>`;

  bindTaskFilterEvents();
  renderTaskView();
}

function bindTaskFilterEvents() {
  const applyFilters = async () => {
    App.taskFilter.status = document.getElementById('filter-status').value;
    App.taskFilter.priority = document.getElementById('filter-priority').value;
    App.taskFilter.assignee_id = document.getElementById('filter-assignee').value;
    App.taskFilter.search = document.getElementById('task-search').value;

    let url = '/tasks?';
    if (App.taskFilter.status) url += `status=${encodeURIComponent(App.taskFilter.status)}&`;
    if (App.taskFilter.priority) url += `priority=${encodeURIComponent(App.taskFilter.priority)}&`;
    if (App.taskFilter.assignee_id) url += `assignee_id=${encodeURIComponent(App.taskFilter.assignee_id)}&`;
    if (App.taskFilter.search) url += `search=${encodeURIComponent(App.taskFilter.search)}&`;

    const r = await api.get(url);
    if (r.ok) App.tasks = r.data.tasks;
    renderTaskView();
  };

  document.getElementById('filter-status').addEventListener('change', applyFilters);
  document.getElementById('filter-priority').addEventListener('change', applyFilters);
  document.getElementById('filter-assignee').addEventListener('change', applyFilters);
  let searchTimer;
  document.getElementById('task-search').addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(applyFilters, 400);
  });

  document.getElementById('view-list').addEventListener('click', () => { App.taskView = 'list'; document.getElementById('view-list').className = 'view-btn active'; document.getElementById('view-kanban').className = 'view-btn'; renderTaskView(); });
  document.getElementById('view-kanban').addEventListener('click', () => { App.taskView = 'kanban'; document.getElementById('view-kanban').className = 'view-btn active'; document.getElementById('view-list').className = 'view-btn'; renderTaskView(); });
  document.getElementById('btn-new-task').addEventListener('click', () => showTaskModal());
}

function renderTaskView() {
  const vc = document.getElementById('task-view-content');
  if (!vc) return;
  if (App.taskView === 'list') {
    vc.innerHTML = renderTaskList(App.tasks);
    bindTaskListEvents();
  } else {
    vc.innerHTML = renderKanbanBoard(App.tasks);
    bindKanbanEvents();
  }
}

function renderTaskList(tasks) {
  if (!tasks.length) return `<div class="card"><div class="card-body"><div class="empty-state"><i class="fas fa-clipboard-list"></i><p>업무가 없습니다</p></div></div></div>`;
  return `<div class="card" style="overflow:hidden">
    <table class="table">
      <thead><tr>
        <th style="width:40%">업무명</th><th>담당자</th><th>상태</th><th>우선순위</th><th>마감일</th><th>선행업무</th><th style="width:80px">액션</th>
      </tr></thead>
      <tbody>${tasks.map(t => {
        const delayed = isDelayed(t.due_date, t.status);
        const dueSoon = dueSoonWarning(t.due_date, t.status);
        return `<tr class="${delayed ? 'opacity-90' : ''}">
          <td>
            <div style="display:flex;align-items:center;gap:8px">
              <span class="priority-dot dot-${t.priority?.toLowerCase()}"></span>
              <span class="hover-primary font-semibold task-title-link" data-id="${t.task_id}" style="cursor:pointer">${escHtml(t.title)}</span>
              ${delayed ? '<span class="badge badge-delayed" style="font-size:10px">지연</span>' : ''}
              ${!delayed && dueSoon ? '<span class="badge badge-medium" style="font-size:10px">임박</span>' : ''}
              ${t.dependency_task_id && t.dependency_status !== 'Done' ? '<i class="fas fa-lock" style="color:#94a3b8;font-size:11px" title="선행업무 미완료"></i>' : ''}
            </div>
          </td>
          <td>${t.assignee_name ? `<div style="display:flex;align-items:center;gap:6px">${avatarHtml(t.assignee_name, t.assignee_color, 'avatar-sm')}<span style="font-size:13px">${escHtml(t.assignee_name)}</span></div>` : '<span style="color:#94a3b8;font-size:13px">미지정</span>'}</td>
          <td>${statusBadge(t.status)}</td>
          <td>${priorityBadge(t.priority)}</td>
          <td style="font-size:13px;color:${delayed?'#ef4444':dueSoon?'#f59e0b':'inherit'}">${formatDate(t.due_date)}</td>
          <td style="font-size:12px;color:#64748b">${t.dependency_title ? `<span title="${escHtml(t.dependency_title)}" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;max-width:100px">${escHtml(t.dependency_title)}</span>` : '-'}</td>
          <td><div class="table-action">
            <button class="btn btn-ghost btn-icon btn-sm task-edit" data-id="${t.task_id}" title="수정"><i class="fas fa-edit"></i></button>
            <button class="btn btn-ghost btn-icon btn-sm task-delete" data-id="${t.task_id}" title="삭제" style="color:#ef4444"><i class="fas fa-trash"></i></button>
          </div></td>
        </tr>`;
      }).join('')}</tbody>
    </table>
  </div>`;
}

function bindTaskListEvents() {
  document.querySelectorAll('.task-title-link').forEach(el => {
    el.addEventListener('click', () => navigate('task-detail', { taskId: el.dataset.id }));
  });
  document.querySelectorAll('.task-edit').forEach(el => {
    el.addEventListener('click', (e) => { e.stopPropagation(); showTaskModal(App.tasks.find(t => t.task_id === el.dataset.id)); });
  });
  document.querySelectorAll('.task-delete').forEach(el => {
    el.addEventListener('click', (e) => { e.stopPropagation(); confirmDeleteTask(el.dataset.id); });
  });
}

function renderKanbanBoard(tasks) {
  const cols = [
    { status: 'To-do', color: '#64748b', icon: 'fa-circle' },
    { status: 'In Progress', color: '#3b82f6', icon: 'fa-play-circle' },
    { status: 'Done', color: '#10b981', icon: 'fa-check-circle' },
  ];
  return `<div class="kanban-board">${cols.map(col => {
    const colTasks = tasks.filter(t => t.status === col.status);
    return `<div class="kanban-col">
      <div class="kanban-col-header">
        <div class="kanban-col-title">
          <i class="fas ${col.icon}" style="color:${col.color}"></i>${col.status}
        </div>
        <span class="kanban-count">${colTasks.length}</span>
      </div>
      ${colTasks.map(t => {
        const delayed = isDelayed(t.due_date, t.status);
        return `<div class="kanban-card ${delayed?'delayed':''}" data-id="${t.task_id}">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:8px">
            <div class="kanban-card-title">${escHtml(t.title)}</div>
            ${priorityBadge(t.priority)}
          </div>
          <div class="kanban-card-meta">
            ${t.assignee_name ? `<div style="display:flex;align-items:center;gap:4px">${avatarHtml(t.assignee_name, t.assignee_color, 'avatar-sm')}<span style="font-size:11px">${escHtml(t.assignee_name)}</span></div>` : '<span style="font-size:11px;color:#94a3b8">미지정</span>'}
            <span style="font-size:11px;color:${delayed?'#ef4444':'#94a3b8'}">${t.due_date ? formatDate(t.due_date) : ''}</span>
          </div>
          ${delayed ? '<div style="margin-top:6px"><span class="badge badge-delayed" style="font-size:10px">지연</span></div>' : ''}
        </div>`;
      }).join('')}
      <button class="btn btn-ghost btn-sm kanban-add" data-status="${col.status}" style="width:100%;margin-top:8px;color:#94a3b8;border:1px dashed #e2e8f0">
        <i class="fas fa-plus"></i> 추가
      </button>
    </div>`;
  }).join('')}</div>`;
}

function bindKanbanEvents() {
  document.querySelectorAll('.kanban-card').forEach(el => {
    el.addEventListener('click', () => navigate('task-detail', { taskId: el.dataset.id }));
  });
  document.querySelectorAll('.kanban-add').forEach(el => {
    el.addEventListener('click', () => showTaskModal(null, el.dataset.status));
  });
}

// ===== Task Modal =====
function showTaskModal(task = null, defaultStatus = 'To-do') {
  const isEdit = !!task;
  const otherTasks = App.tasks.filter(t => !task || t.task_id !== task.task_id);

  const html = `
  <div class="modal-header">
    <div class="modal-title">${isEdit ? '업무 수정' : '새 업무 추가'}</div>
    <button class="btn-icon btn-ghost" onclick="closeModal()"><i class="fas fa-times"></i></button>
  </div>
  <div class="modal-body">
    <div class="form-group">
      <label class="form-label">업무명 <span style="color:#ef4444">*</span></label>
      <input id="t-title" class="form-control" placeholder="업무명을 입력하세요" value="${task ? escHtml(task.title) : ''}">
    </div>
    <div class="form-group">
      <label class="form-label">설명</label>
      <textarea id="t-desc" class="form-control" rows="3" placeholder="업무 설명 (선택)">${task ? escHtml(task.description || '') : ''}</textarea>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="form-group">
        <label class="form-label">담당자</label>
        <select id="t-assignee" class="form-control form-select">
          <option value="">담당자 선택</option>
          ${App.users.map(u => `<option value="${u.user_id}" ${task?.assignee_id===u.user_id?'selected':''}>${escHtml(u.name)}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">상태</label>
        <select id="t-status" class="form-control form-select">
          <option value="To-do" ${(task?.status||defaultStatus)==='To-do'?'selected':''}>To-do</option>
          <option value="In Progress" ${(task?.status||defaultStatus)==='In Progress'?'selected':''}>In Progress</option>
          <option value="Done" ${(task?.status||defaultStatus)==='Done'?'selected':''}>Done</option>
        </select>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="form-group">
        <label class="form-label">우선순위</label>
        <select id="t-priority" class="form-control form-select">
          <option value="Low" ${task?.priority==='Low'?'selected':''}>Low</option>
          <option value="Medium" ${task?.priority==='Medium'||!task?'selected':''}>Medium</option>
          <option value="High" ${task?.priority==='High'?'selected':''}>High</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">마감일</label>
        <input id="t-due" class="form-control" type="datetime-local" value="${task?.due_date ? task.due_date.replace(' ','T').substring(0,16) : ''}">
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">선행 업무 (의존성)</label>
      <select id="t-dep" class="form-control form-select">
        <option value="">선행 업무 없음</option>
        ${otherTasks.map(t => `<option value="${t.task_id}" ${task?.dependency_task_id===t.task_id?'selected':''}>${escHtml(t.title)} [${t.status}]</option>`).join('')}
      </select>
    </div>
  </div>
  <div class="modal-footer">
    <button class="btn btn-secondary" onclick="closeModal()">취소</button>
    <button class="btn btn-primary" id="save-task-btn">${isEdit ? '저장' : '추가'}</button>
  </div>`;

  showModal(html);
  document.getElementById('save-task-btn').addEventListener('click', async () => {
    const title = document.getElementById('t-title').value.trim();
    if (!title) { toast('업무명을 입력하세요.', 'error'); return; }

    const data = {
      title,
      description: document.getElementById('t-desc').value.trim() || null,
      assignee_id: document.getElementById('t-assignee').value || null,
      status: document.getElementById('t-status').value,
      priority: document.getElementById('t-priority').value,
      due_date: document.getElementById('t-due').value ? document.getElementById('t-due').value.replace('T',' ') + ':00' : null,
      dependency_task_id: document.getElementById('t-dep').value || null,
    };

    const r = isEdit ? await api.put(`/tasks/${task.task_id}`, data) : await api.post('/tasks', data);
    if (r.ok) {
      toast(isEdit ? '업무가 수정되었습니다.' : '업무가 추가되었습니다.', 'success');
      const tr = await api.get('/tasks');
      if (tr.ok) App.tasks = tr.data.tasks;
      closeModal();
      renderTaskView();
    } else {
      toast(r.error, 'error');
    }
  });
}

async function confirmDeleteTask(taskId) {
  const task = App.tasks.find(t => t.task_id === taskId);
  if (!task) return;
  if (!confirm(`"${task.title}" 업무를 삭제하시겠습니까?`)) return;
  const r = await api.delete(`/tasks/${taskId}`);
  if (r.ok) {
    toast('업무가 삭제되었습니다.', 'success');
    App.tasks = App.tasks.filter(t => t.task_id !== taskId);
    renderTaskView();
  } else {
    toast(r.error, 'error');
  }
}

// ===== Task Detail Page =====
async function renderTaskDetail() {
  const content = document.getElementById('page-content');
  content.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:200px"><div class="spinner" style="width:36px;height:36px;border-width:3px"></div></div>';

  const [taskR, commentsR, logsR, attachR] = await Promise.all([
    api.get(`/tasks/${App.currentTaskId}`),
    api.get(`/tasks/${App.currentTaskId}/comments`),
    api.get(`/tasks/${App.currentTaskId}/activity-logs`),
    api.get(`/tasks/${App.currentTaskId}/attachments`),
  ]);

  if (!taskR.ok) { toast('업무를 불러오지 못했습니다.', 'error'); navigate('tasks'); return; }

  const task = taskR.data.task;
  const comments = commentsR.ok ? commentsR.data.comments : [];
  const logs = logsR.ok ? logsR.data.logs : [];
  const attachments = attachR.ok ? attachR.data.attachments : [];
  const delayed = isDelayed(task.due_date, task.status);

  const issuesR = await api.get(`/issues?task_id=${App.currentTaskId}`);
  const taskIssues = issuesR.ok ? issuesR.data.issues : [];

  content.innerHTML = `
  <div style="margin-bottom:12px">
    <button class="btn btn-ghost btn-sm" id="back-to-tasks"><i class="fas fa-arrow-left"></i> 업무 목록</button>
  </div>
  <div class="detail-grid">
    <div style="display:flex;flex-direction:column;gap:16px">
      <div class="card">
        <div class="card-header">
          <div style="flex:1">
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <h3 style="margin:0;font-size:20px;font-weight:700">${escHtml(task.title)}</h3>
              ${delayed ? '<span class="badge badge-delayed">지연</span>' : ''}
              ${task.dependency_task_id && task.dependency_status !== 'Done' ? '<span class="badge" style="background:#ede9fe;color:#5b21b6"><i class="fas fa-lock"></i> 선행 미완료</span>' : ''}
            </div>
          </div>
          <div style="display:flex;gap:6px">
            <button class="btn btn-secondary btn-sm" id="edit-task-btn"><i class="fas fa-edit"></i> 수정</button>
            <button class="btn btn-danger btn-sm" id="delete-task-btn"><i class="fas fa-trash"></i></button>
          </div>
        </div>
        <div class="card-body">
          ${task.description ? `<p style="margin:0 0 16px;color:#374151;line-height:1.6">${escHtml(task.description)}</p>` : ''}
          <div class="info-row"><div class="info-label"><i class="fas fa-user" style="color:#6366f1;width:14px"></i> 담당자</div>
            <div class="info-value">${task.assignee_name ? `<div style="display:flex;align-items:center;gap:6px">${avatarHtml(task.assignee_name, task.assignee_color, 'avatar-sm')}<span>${escHtml(task.assignee_name)}</span></div>` : '<span style="color:#94a3b8">미지정</span>'}</div></div>
          <div class="info-row"><div class="info-label"><i class="fas fa-circle" style="color:#3b82f6;width:14px"></i> 상태</div>
            <div class="info-value"><select id="detail-status" class="form-control form-select" style="width:160px;display:inline-block">
              <option value="To-do" ${task.status==='To-do'?'selected':''}>To-do</option>
              <option value="In Progress" ${task.status==='In Progress'?'selected':''}>In Progress</option>
              <option value="Done" ${task.status==='Done'?'selected':''}>Done</option>
            </select></div></div>
          <div class="info-row"><div class="info-label"><i class="fas fa-flag" style="color:#f59e0b;width:14px"></i> 우선순위</div>
            <div class="info-value">${priorityBadge(task.priority)}</div></div>
          <div class="info-row"><div class="info-label"><i class="fas fa-calendar" style="color:#10b981;width:14px"></i> 마감일</div>
            <div class="info-value" style="color:${delayed?'#ef4444':'inherit'}">${formatDate(task.due_date) || '-'}</div></div>
          <div class="info-row"><div class="info-label"><i class="fas fa-link" style="color:#94a3b8;width:14px"></i> 선행 업무</div>
            <div class="info-value">${task.dependency_title ? `<span style="font-size:13px">${escHtml(task.dependency_title)}</span> ${statusBadge(task.dependency_status||'To-do')}` : '-'}</div></div>
          <div class="info-row"><div class="info-label"><i class="fas fa-user-plus" style="color:#94a3b8;width:14px"></i> 생성자</div>
            <div class="info-value" style="font-size:13px;color:#64748b">${escHtml(task.creator_name||'-')} · ${formatDateTime(task.created_at)}</div></div>
        </div>
      </div>

      <div class="card">
        <div style="padding:0 20px">
          <div class="tabs" id="detail-tabs">
            <div class="tab-item active" data-tab="comments">댓글 (${comments.length})</div>
            <div class="tab-item" data-tab="attachments">파일 (${attachments.length})</div>
            <div class="tab-item" data-tab="issues">이슈 (${taskIssues.length})</div>
            <div class="tab-item" data-tab="logs">변경 이력 (${logs.length})</div>
          </div>
        </div>
        <div id="detail-tab-content" class="card-body"></div>
      </div>
    </div>

    <div style="display:flex;flex-direction:column;gap:16px">
      <div class="card">
        <div class="card-header"><span style="font-weight:600;font-size:14px"><i class="fas fa-calendar" style="color:#6366f1"></i> 관련 일정</span></div>
        <div class="card-body" style="padding:12px">
          ${App.schedules.filter(s => s.related_task_id === App.currentTaskId).length ?
            App.schedules.filter(s => s.related_task_id === App.currentTaskId).map(s => `
              <div style="padding:8px;border-radius:6px;background:#f8fafc;margin-bottom:6px;font-size:13px">
                <div style="font-weight:500">${escHtml(s.title)}</div>
                <div style="color:#64748b;font-size:11px">${formatDate(s.start_date)}</div>
              </div>`).join('')
            : '<p style="color:#94a3b8;font-size:13px;margin:0">관련 일정 없음</p>'}
        </div>
      </div>
      <div class="card">
        <div class="card-header"><span style="font-weight:600;font-size:14px"><i class="fas fa-users" style="color:#6366f1"></i> 팀원</span></div>
        <div class="card-body" style="padding:12px">
          ${App.users.map(u => `<div style="display:flex;align-items:center;gap:8px;padding:6px 0">
            ${avatarHtml(u.name, u.avatar_color, 'avatar-sm')}
            <span style="font-size:13px">${escHtml(u.name)}</span>
          </div>`).join('')}
        </div>
      </div>
    </div>
  </div>`;

  function renderTab(tab) {
    const tc = document.getElementById('detail-tab-content');
    document.querySelectorAll('#detail-tabs .tab-item').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
    if (tab === 'comments') {
      tc.innerHTML = `
        <div id="comments-list">${renderCommentsList(comments)}</div>
        <div style="margin-top:12px;display:flex;gap:8px">
          <textarea id="new-comment" class="form-control" rows="2" placeholder="댓글을 입력하세요..."></textarea>
          <button class="btn btn-primary" id="submit-comment" style="white-space:nowrap"><i class="fas fa-paper-plane"></i></button>
        </div>`;
      document.getElementById('submit-comment').addEventListener('click', async () => {
        const c = document.getElementById('new-comment').value.trim();
        if (!c) return;
        const r = await api.post(`/tasks/${App.currentTaskId}/comments`, { content: c });
        if (r.ok) {
          comments.push(r.data.comment);
          document.getElementById('comments-list').innerHTML = renderCommentsList(comments);
          document.getElementById('new-comment').value = '';
          toast('댓글이 등록되었습니다.', 'success');
        } else toast(r.error, 'error');
      });
    } else if (tab === 'attachments') {
      tc.innerHTML = `
        <div id="attachments-list">${renderAttachmentsList(attachments)}</div>
        <div style="margin-top:12px">
          <label class="btn btn-secondary btn-sm" style="cursor:pointer"><i class="fas fa-paperclip"></i> 파일 첨부
            <input type="file" id="file-input" style="display:none" multiple>
          </label>
        </div>`;
      document.getElementById('file-input').addEventListener('change', async (e) => {
        const files = Array.from(e.target.files);
        for (const file of files) {
          if (file.size > 10 * 1024 * 1024) { toast(`${file.name}: 파일 크기 10MB 초과`, 'error'); continue; }
          const reader = new FileReader();
          reader.onload = async (ev) => {
            const r = await api.post(`/tasks/${App.currentTaskId}/attachments`, {
              file_name: file.name, file_data: ev.target.result, file_size: file.size, file_type: file.type
            });
            if (r.ok) {
              attachments.push(r.data.attachment);
              document.getElementById('attachments-list').innerHTML = renderAttachmentsList(attachments);
              toast(`${file.name} 첨부 완료`, 'success');
            } else toast(r.error, 'error');
          };
          reader.readAsDataURL(file);
        }
      });
    } else if (tab === 'issues') {
      tc.innerHTML = `
        <div id="task-issues-list">${renderTaskIssuesList(taskIssues)}</div>
        <button class="btn btn-secondary btn-sm" id="add-issue-btn" style="margin-top:8px"><i class="fas fa-plus"></i> 이슈 추가</button>`;
      document.getElementById('add-issue-btn').addEventListener('click', () => showIssueModal(null, App.currentTaskId));
    } else if (tab === 'logs') {
      tc.innerHTML = renderActivityLogs(logs);
    }
  }

  document.querySelectorAll('#detail-tabs .tab-item').forEach(t => {
    t.addEventListener('click', () => renderTab(t.dataset.tab));
  });
  renderTab('comments');

  document.getElementById('detail-status').addEventListener('change', async (e) => {
    const r = await api.patch(`/tasks/${task.task_id}/status`, { status: e.target.value });
    if (r.ok) { toast('상태가 변경되었습니다.', 'success'); task.status = e.target.value; }
    else { toast(r.error, 'error'); }
  });

  document.getElementById('back-to-tasks').addEventListener('click', () => navigate('tasks'));
  document.getElementById('edit-task-btn').addEventListener('click', () => showTaskModal(task));
  document.getElementById('delete-task-btn').addEventListener('click', async () => {
    if (!confirm(`"${task.title}" 업무를 삭제하시겠습니까?`)) return;
    const r = await api.delete(`/tasks/${task.task_id}`);
    if (r.ok) { toast('업무가 삭제되었습니다.', 'success'); navigate('tasks'); }
    else toast(r.error, 'error');
  });
}

function renderCommentsList(comments) {
  if (!comments.length) return '<div class="empty-state" style="padding:20px"><i class="fas fa-comment"></i><p>아직 댓글이 없습니다</p></div>';
  return comments.map(c => `
    <div class="activity-item">
      ${avatarHtml(c.user_name||'?', '#6366f1', 'avatar-sm')}
      <div style="flex:1">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
          <span style="font-size:13px;font-weight:600">${escHtml(c.user_name||'알 수 없음')}</span>
          <span class="activity-time">${formatDateTime(c.created_at)}</span>
        </div>
        <p style="margin:0;font-size:14px;color:#374151;line-height:1.5">${escHtml(c.content)}</p>
      </div>
    </div>`).join('');
}

function renderAttachmentsList(attachments) {
  if (!attachments.length) return '<div class="empty-state" style="padding:20px"><i class="fas fa-paperclip"></i><p>첨부 파일이 없습니다</p></div>';
  return attachments.map(a => {
    const icon = a.file_type?.startsWith('image/') ? 'fa-image' : a.file_type?.includes('pdf') ? 'fa-file-pdf' : 'fa-file';
    const size = a.file_size > 1024*1024 ? `${(a.file_size/1024/1024).toFixed(1)}MB` : `${Math.round(a.file_size/1024)}KB`;
    return `<div class="attachment-item">
      <div class="attachment-icon"><i class="fas ${icon}"></i></div>
      <div style="flex:1;min-width:0">
        <div style="font-size:13px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escHtml(a.file_name)}</div>
        <div style="font-size:11px;color:#94a3b8">${size} · ${escHtml(a.uploader_name||'')} · ${formatDate(a.created_at)}</div>
      </div>
      <button class="btn btn-ghost btn-icon btn-sm attach-del" data-id="${a.attachment_id}" style="color:#ef4444"><i class="fas fa-trash"></i></button>
    </div>`;
  }).join('');
}

function renderTaskIssuesList(issues) {
  if (!issues.length) return '<div class="empty-state" style="padding:20px"><i class="fas fa-check"></i><p>관련 이슈 없음</p></div>';
  return issues.map(i => `
    <div style="padding:10px;border-radius:8px;border:1px solid #f1f5f9;margin-bottom:6px;display:flex;align-items:center;gap:8px">
      <div style="flex:1">
        <div style="font-size:13px;font-weight:500">${escHtml(i.title)}</div>
        <div style="font-size:11px;color:#64748b;margin-top:2px">${formatDate(i.created_at)}</div>
      </div>
      ${priorityBadge(i.priority)} ${statusBadge(i.status)}
    </div>`).join('');
}

function renderActivityLogs(logs) {
  if (!logs.length) return '<div class="empty-state" style="padding:20px"><i class="fas fa-history"></i><p>변경 이력이 없습니다</p></div>';
  const actionLabels = { create:'생성', update:'수정', delete:'삭제', status_change:'상태 변경', assign:'담당자 변경', change_due_date:'마감일 변경' };
  return logs.map(l => {
    let detail = '';
    try {
      if (l.action === 'status_change') {
        const b = JSON.parse(l.before_value||'{}'), a = JSON.parse(l.after_value||'{}');
        detail = `${b.status||'?'} → ${a.status||'?'}`;
      } else if (l.action === 'assign') {
        const a = JSON.parse(l.after_value||'{}');
        const user = App.users.find(u => u.user_id === a.assignee_id);
        detail = `담당자: ${user?.name || '미지정'}`;
      } else if (l.action === 'change_due_date') {
        const a = JSON.parse(l.after_value||'{}');
        detail = `마감일: ${formatDate(a.due_date)}`;
      }
    } catch(e) {}
    return `<div class="activity-item">
      <div class="activity-dot"></div>
      <div class="activity-content">
        <div><strong>${escHtml(l.actor_name||'알 수 없음')}</strong>이 ${actionLabels[l.action]||l.action}했습니다${detail ? ': ' + detail : ''}</div>
        <div class="activity-time">${formatDateTime(l.created_at)}</div>
      </div>
    </div>`;
  }).join('');
}

// ===== Schedules Page =====
function renderSchedulesPage() {
  const content = document.getElementById('page-content');
  content.innerHTML = `
  <div style="display:flex;flex-direction:column;gap:16px">
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
      <div style="display:flex;align-items:center;gap:8px">
        <button class="btn btn-ghost btn-icon" id="cal-prev"><i class="fas fa-chevron-left"></i></button>
        <span id="cal-title" style="font-size:16px;font-weight:600;min-width:140px;text-align:center"></span>
        <button class="btn btn-ghost btn-icon" id="cal-next"><i class="fas fa-chevron-right"></i></button>
        <button class="btn btn-secondary btn-sm" id="cal-today">오늘</button>
      </div>
      <div style="display:flex;gap:8px">
        <div class="view-toggle">
          <button class="view-btn ${App.calendarView==='month'?'active':''}" id="cal-month">월</button>
          <button class="view-btn ${App.calendarView==='week'?'active':''}" id="cal-week">주</button>
        </div>
        <button class="btn btn-primary" id="btn-new-schedule"><i class="fas fa-plus"></i> 일정 추가</button>
      </div>
    </div>
    <div style="display:flex;gap:12px;flex-wrap:wrap">
      ${[['task','업무마감','#ede9fe','#5b21b6'],['meeting','회의','#dbeafe','#1e40af'],['vacation','휴가','#d1fae5','#065f46'],['business_trip','출장','#fef3c7','#92400e'],['out_of_office','외근','#fce7f3','#9d174d'],['personal','개인','#f3f4f6','#374151']].map(([,label,bg,color]) => `<div style="display:flex;align-items:center;gap:4px"><div style="width:10px;height:10px;border-radius:2px;background:${bg};border:1px solid ${color}"></div><span style="font-size:12px;color:#64748b">${label}</span></div>`).join('')}
    </div>
    <div id="calendar-container" class="card"><div class="card-body" style="padding:0" id="calendar-body"></div></div>
  </div>`;

  document.getElementById('cal-prev').addEventListener('click', () => { App.calendarDate = App.calendarView === 'month' ? App.calendarDate.subtract(1,'month') : App.calendarDate.subtract(1,'week'); renderCalendar(); });
  document.getElementById('cal-next').addEventListener('click', () => { App.calendarDate = App.calendarView === 'month' ? App.calendarDate.add(1,'month') : App.calendarDate.add(1,'week'); renderCalendar(); });
  document.getElementById('cal-today').addEventListener('click', () => { App.calendarDate = dayjs(); renderCalendar(); });
  document.getElementById('cal-month').addEventListener('click', () => { App.calendarView = 'month'; document.getElementById('cal-month').className='view-btn active'; document.getElementById('cal-week').className='view-btn'; renderCalendar(); });
  document.getElementById('cal-week').addEventListener('click', () => { App.calendarView = 'week'; document.getElementById('cal-week').className='view-btn active'; document.getElementById('cal-month').className='view-btn'; renderCalendar(); });
  document.getElementById('btn-new-schedule').addEventListener('click', () => showScheduleModal());

  renderCalendar();
}

function renderCalendar() {
  const title = document.getElementById('cal-title');
  const body = document.getElementById('calendar-body');
  if (App.calendarView === 'month') {
    title.textContent = App.calendarDate.format('YYYY년 MM월');
    body.innerHTML = renderMonthCalendar();
  } else {
    const startOfWeek = App.calendarDate.startOf('week');
    const endOfWeek = App.calendarDate.endOf('week');
    title.textContent = `${startOfWeek.format('YYYY.MM.DD')} ~ ${endOfWeek.format('MM.DD')}`;
    body.innerHTML = renderWeekCalendar();
  }
  bindCalendarEvents();
}

function renderMonthCalendar() {
  const start = App.calendarDate.startOf('month').startOf('week');
  const end = App.calendarDate.endOf('month').endOf('week');
  const days = ['일', '월', '화', '수', '목', '금', '토'];

  let html = `<div class="calendar-grid">${days.map(d => `<div class="calendar-header-cell">${d}</div>`).join('')}`;

  let current = start;
  while (current.isBefore(end) || current.isSame(end, 'day')) {
    const isToday = current.isSame(dayjs(), 'day');
    const isOtherMonth = !current.isSame(App.calendarDate, 'month');
    const dateStr = current.format('YYYY-MM-DD');

    const daySchedules = App.schedules.filter(s => {
      const sd = dayjs(s.start_date).format('YYYY-MM-DD');
      const ed = dayjs(s.end_date).format('YYYY-MM-DD');
      return dateStr >= sd && dateStr <= ed;
    }).slice(0, 3);

    const dayTasks = App.tasks.filter(t => t.due_date && dayjs(t.due_date).format('YYYY-MM-DD') === dateStr && t.status !== 'Done').slice(0, 2);

    html += `<div class="calendar-cell ${isToday?'today':''} ${isOtherMonth?'other-month':''}" data-date="${dateStr}">
      <div class="cell-day">${current.date()}</div>
      ${daySchedules.map(s => {
        const typeClass = `cal-${s.type.replace('_','-')}`;
        return `<div class="calendar-event ${typeClass}" data-sch-id="${s.schedule_id}" title="${escHtml(s.title)}">${escHtml(s.title)}</div>`;
      }).join('')}
      ${dayTasks.length && !daySchedules.find(s => s.type === 'task') ? dayTasks.map(t => `<div class="calendar-event cal-task" data-task-id="${t.task_id}" style="opacity:0.7" title="업무: ${escHtml(t.title)}">📋 ${escHtml(t.title)}</div>`).join('') : ''}
    </div>`;
    current = current.add(1, 'day');
  }
  html += '</div>';
  return html;
}

function renderWeekCalendar() {
  const start = App.calendarDate.startOf('week');
  const days = Array.from({length: 7}, (_, i) => start.add(i, 'day'));

  let html = `<div style="overflow-x:auto"><div class="week-header">
    <div style="border-right:1px solid #e2e8f0;padding:8px"></div>
    ${days.map(d => `<div class="week-col-header ${d.isSame(dayjs(),'day')?'today':''}">
      <div style="font-size:11px;color:#64748b">${['일','월','화','수','목','금','토'][d.day()]}</div>
      <div style="font-size:20px;font-weight:600">${d.date()}</div>
    </div>`).join('')}
  </div>
  <div style="position:relative">
    ${Array.from({length: 24}, (_, h) => `
      <div class="week-body">
        <div class="week-time-col" style="border-right:1px solid #e2e8f0;border-bottom:1px solid #f1f5f9;min-height:48px;padding-top:4px">${h}:00</div>
        ${days.map(d => {
          const dateStr = d.format('YYYY-MM-DD');
          const hourEvents = App.schedules.filter(s => {
            const sh = dayjs(s.start_date);
            return sh.format('YYYY-MM-DD') === dateStr && sh.hour() === h;
          });
          return `<div class="week-cell" data-date="${dateStr}" data-hour="${h}">
            ${hourEvents.map(s => {
              const typeClass = `cal-${s.type.replace('_','-')}`;
              return `<div class="week-event ${typeClass}" data-sch-id="${s.schedule_id}" style="top:2px">${escHtml(s.title)}</div>`;
            }).join('')}
          </div>`;
        }).join('')}
      </div>`).join('')}
  </div></div>`;
  return html;
}

function bindCalendarEvents() {
  document.querySelectorAll('.calendar-cell').forEach(cell => {
    cell.addEventListener('click', (e) => {
      if (e.target.classList.contains('calendar-event')) return;
      showScheduleModal(null, cell.dataset.date);
    });
  });
  document.querySelectorAll('.calendar-event[data-sch-id]').forEach(el => {
    el.addEventListener('click', async (e) => {
      e.stopPropagation();
      const sch = App.schedules.find(s => s.schedule_id === el.dataset.schId);
      if (sch) showScheduleDetailModal(sch);
    });
  });
  document.querySelectorAll('.calendar-event[data-task-id]').forEach(el => {
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      navigate('task-detail', { taskId: el.dataset.taskId });
    });
  });
  document.querySelectorAll('.week-cell').forEach(cell => {
    cell.addEventListener('click', (e) => {
      if (e.target.classList.contains('week-event')) return;
      showScheduleModal(null, cell.dataset.date, cell.dataset.hour);
    });
  });
  document.querySelectorAll('.week-event[data-sch-id]').forEach(el => {
    el.addEventListener('click', async (e) => {
      e.stopPropagation();
      const sch = App.schedules.find(s => s.schedule_id === el.dataset.schId);
      if (sch) showScheduleDetailModal(sch);
    });
  });
}

function showScheduleDetailModal(sch) {
  const typeNames = { task:'업무마감', meeting:'회의', business_trip:'출장', vacation:'휴가', out_of_office:'외근', personal:'개인일정', etc:'기타' };
  const html = `
  <div class="modal-header">
    <div class="modal-title">${escHtml(sch.title)}</div>
    <button class="btn-icon btn-ghost" onclick="closeModal()"><i class="fas fa-times"></i></button>
  </div>
  <div class="modal-body">
    <div class="info-row"><div class="info-label">유형</div><div class="info-value">${typeNames[sch.type]||sch.type}</div></div>
    <div class="info-row"><div class="info-label">시작</div><div class="info-value">${formatDateTime(sch.start_date)}</div></div>
    <div class="info-row"><div class="info-label">종료</div><div class="info-value">${formatDateTime(sch.end_date)}</div></div>
    ${sch.task_title ? `<div class="info-row"><div class="info-label">관련 업무</div><div class="info-value">${escHtml(sch.task_title)}</div></div>` : ''}
    ${sch.description ? `<div class="info-row"><div class="info-label">설명</div><div class="info-value">${escHtml(sch.description)}</div></div>` : ''}
  </div>
  <div class="modal-footer">
    <button class="btn btn-danger btn-sm" id="del-sch-btn">삭제</button>
    <button class="btn btn-secondary" id="edit-sch-btn">수정</button>
    <button class="btn btn-primary" onclick="closeModal()">닫기</button>
  </div>`;

  showModal(html);
  document.getElementById('del-sch-btn').addEventListener('click', async () => {
    if (!confirm('이 일정을 삭제하시겠습니까?')) return;
    const r = await api.delete(`/schedules/${sch.schedule_id}`);
    if (r.ok) {
      App.schedules = App.schedules.filter(s => s.schedule_id !== sch.schedule_id);
      toast('일정이 삭제되었습니다.', 'success');
      closeModal();
      renderCalendar();
    } else toast(r.error, 'error');
  });
  document.getElementById('edit-sch-btn').addEventListener('click', () => { closeModal(); showScheduleModal(sch); });
}

function showScheduleModal(sch = null, defaultDate = null, defaultHour = null) {
  const isEdit = !!sch;
  const defaultStart = defaultDate ? `${defaultDate}T${defaultHour ? defaultHour.padStart(2,'0') : '09'}:00` : '';
  const defaultEnd = defaultDate ? `${defaultDate}T${defaultHour ? String(parseInt(defaultHour)+1).padStart(2,'0') : '10'}:00` : '';

  const currentOwnerId = sch?.owner_id || App.currentUser?.user_id || (App.users[0]?.user_id || '');

  const html = `
  <div class="modal-header">
    <div class="modal-title">${isEdit ? '일정 수정' : '일정 추가'}</div>
    <button class="btn-icon btn-ghost" onclick="closeModal()"><i class="fas fa-times"></i></button>
  </div>
  <div class="modal-body">
    <div class="form-group">
      <label class="form-label">일정명 <span style="color:#ef4444">*</span></label>
      <input id="s-title" class="form-control" placeholder="일정명" value="${sch ? escHtml(sch.title) : ''}">
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="form-group">
        <label class="form-label">시작일시</label>
        <input id="s-start" class="form-control" type="datetime-local" value="${sch ? sch.start_date.replace(' ','T').substring(0,16) : defaultStart}">
      </div>
      <div class="form-group">
        <label class="form-label">종료일시</label>
        <input id="s-end" class="form-control" type="datetime-local" value="${sch ? sch.end_date.replace(' ','T').substring(0,16) : defaultEnd}">
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="form-group">
        <label class="form-label">유형</label>
        <select id="s-type" class="form-control form-select">
          <option value="meeting" ${(sch?.type||'meeting')==='meeting'?'selected':''}>회의</option>
          <option value="business_trip" ${sch?.type==='business_trip'?'selected':''}>출장</option>
          <option value="vacation" ${sch?.type==='vacation'?'selected':''}>휴가</option>
          <option value="out_of_office" ${sch?.type==='out_of_office'?'selected':''}>외근</option>
          <option value="personal" ${sch?.type==='personal'?'selected':''}>개인일정</option>
          <option value="task" ${sch?.type==='task'?'selected':''}>업무마감</option>
          <option value="etc" ${sch?.type==='etc'?'selected':''}>기타</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">담당자</label>
        <select id="s-owner" class="form-control form-select">
          ${App.users.map(u => `<option value="${u.user_id}" ${currentOwnerId===u.user_id?'selected':''}>${escHtml(u.name)}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">관련 업무</label>
      <select id="s-task" class="form-control form-select">
        <option value="">연결 없음</option>
        ${App.tasks.filter(t=>t.status!=='Done').map(t => `<option value="${t.task_id}" ${sch?.related_task_id===t.task_id?'selected':''}>${escHtml(t.title)}</option>`).join('')}
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">설명</label>
      <textarea id="s-desc" class="form-control" rows="2">${sch ? escHtml(sch.description||'') : ''}</textarea>
    </div>
  </div>
  <div class="modal-footer">
    <button class="btn btn-secondary" onclick="closeModal()">취소</button>
    <button class="btn btn-primary" id="save-sch-btn">${isEdit ? '저장' : '추가'}</button>
  </div>`;

  showModal(html);
  document.getElementById('save-sch-btn').addEventListener('click', async () => {
    const title = document.getElementById('s-title').value.trim();
    if (!title) { toast('일정명을 입력하세요.', 'error'); return; }
    const start = document.getElementById('s-start').value;
    const end = document.getElementById('s-end').value;
    if (!start || !end) { toast('시작/종료 일시를 입력하세요.', 'error'); return; }
    if (new Date(start) > new Date(end)) { toast('시작일시가 종료일시보다 늦습니다.', 'error'); return; }

    const data = {
      title, type: document.getElementById('s-type').value,
      start_date: start.replace('T',' ') + ':00',
      end_date: end.replace('T',' ') + ':00',
      owner_id: document.getElementById('s-owner').value,
      related_task_id: document.getElementById('s-task').value || null,
      description: document.getElementById('s-desc').value.trim() || null,
    };

    const r = isEdit ? await api.put(`/schedules/${sch.schedule_id}`, data) : await api.post('/schedules', data);
    if (r.ok) {
      if (r.data.warning) toast(r.data.warning, 'warning');
      else toast(isEdit ? '일정이 수정되었습니다.' : '일정이 추가되었습니다.', 'success');
      const sr = await api.get('/schedules');
      if (sr.ok) App.schedules = sr.data.schedules;
      closeModal();
      renderCalendar();
    } else toast(r.error, 'error');
  });
}

// ===== Issues Page =====
function renderIssuesPage() {
  const content = document.getElementById('page-content');

  const filteredIssues = App.issues.filter(i => {
    if (App.issueFilter.status && i.status !== App.issueFilter.status) return false;
    if (App.issueFilter.priority && i.priority !== App.issueFilter.priority) return false;
    return true;
  });

  content.innerHTML = `
  <div style="display:flex;flex-direction:column;gap:16px">
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
      <div class="filter-bar">
        <select class="filter-select" id="issue-filter-status">
          <option value="">전체 상태</option>
          <option value="Open" ${App.issueFilter.status==='Open'?'selected':''}>Open</option>
          <option value="In Progress" ${App.issueFilter.status==='In Progress'?'selected':''}>In Progress</option>
          <option value="Resolved" ${App.issueFilter.status==='Resolved'?'selected':''}>Resolved</option>
        </select>
        <select class="filter-select" id="issue-filter-priority">
          <option value="">전체 중요도</option>
          <option value="Critical" ${App.issueFilter.priority==='Critical'?'selected':''}>Critical</option>
          <option value="High" ${App.issueFilter.priority==='High'?'selected':''}>High</option>
          <option value="Medium" ${App.issueFilter.priority==='Medium'?'selected':''}>Medium</option>
          <option value="Low" ${App.issueFilter.priority==='Low'?'selected':''}>Low</option>
        </select>
        <span style="font-size:13px;color:#64748b">${filteredIssues.length}건</span>
      </div>
      <button class="btn btn-primary" id="btn-new-issue"><i class="fas fa-plus"></i> 이슈 추가</button>
    </div>
    <div class="card" style="overflow:hidden">
      ${filteredIssues.length ? `
      <table class="table">
        <thead><tr><th>제목</th><th>중요도</th><th>상태</th><th>관련 업무</th><th>등록자</th><th>등록일</th><th>액션</th></tr></thead>
        <tbody>${filteredIssues.map(i => {
          const isUnresolved = i.status !== 'Resolved';
          return `<tr style="${isUnresolved && i.priority === 'Critical' ? 'background:#fff5f5' : ''}">
            <td>
              <div style="display:flex;align-items:center;gap:6px">
                ${isUnresolved ? '<i class="fas fa-exclamation-circle" style="color:#ef4444;font-size:12px"></i>' : '<i class="fas fa-check-circle" style="color:#10b981;font-size:12px"></i>'}
                <span style="font-size:13px;font-weight:500">${escHtml(i.title)}</span>
              </div>
            </td>
            <td>${priorityBadge(i.priority)}</td>
            <td>${statusBadge(i.status)}</td>
            <td>${i.task_title ? `<span style="font-size:12px;color:#6366f1;cursor:pointer" onclick="navigate('task-detail',{taskId:'${i.task_id}'})">${escHtml(i.task_title)}</span>` : '<span style="color:#94a3b8;font-size:12px">-</span>'}</td>
            <td style="font-size:12px">${escHtml(i.creator_name||'-')}</td>
            <td style="font-size:12px;color:#64748b">${formatDate(i.created_at)}</td>
            <td><div class="table-action">
              <button class="btn btn-ghost btn-icon btn-sm issue-edit" data-id="${i.issue_id}"><i class="fas fa-edit"></i></button>
              <button class="btn btn-ghost btn-icon btn-sm issue-status" data-id="${i.issue_id}" data-status="${i.status}" title="상태 변경"><i class="fas fa-exchange-alt"></i></button>
              <button class="btn btn-ghost btn-icon btn-sm issue-delete" data-id="${i.issue_id}" style="color:#ef4444"><i class="fas fa-trash"></i></button>
            </div></td>
          </tr>`;
        }).join('')}</tbody>
      </table>` :
      '<div class="empty-state"><i class="fas fa-check-circle" style="color:#10b981"></i><p>이슈가 없습니다</p></div>'}
    </div>
  </div>`;

  document.getElementById('issue-filter-status').addEventListener('change', (e) => { App.issueFilter.status = e.target.value; renderIssuesPage(); });
  document.getElementById('issue-filter-priority').addEventListener('change', (e) => { App.issueFilter.priority = e.target.value; renderIssuesPage(); });
  document.getElementById('btn-new-issue').addEventListener('click', () => showIssueModal());
  document.querySelectorAll('.issue-edit').forEach(el => {
    el.addEventListener('click', () => showIssueModal(App.issues.find(i => i.issue_id === el.dataset.id)));
  });
  document.querySelectorAll('.issue-status').forEach(el => {
    el.addEventListener('click', () => showIssueStatusModal(el.dataset.id, el.dataset.status));
  });
  document.querySelectorAll('.issue-delete').forEach(el => {
    el.addEventListener('click', async () => {
      const issue = App.issues.find(i => i.issue_id === el.dataset.id);
      if (!issue || !confirm(`"${issue.title}" 이슈를 삭제하시겠습니까?`)) return;
      const r = await api.delete(`/issues/${el.dataset.id}`);
      if (r.ok) { toast('이슈가 삭제되었습니다.', 'success'); App.issues = App.issues.filter(i => i.issue_id !== el.dataset.id); renderIssuesPage(); }
      else toast(r.error, 'error');
    });
  });
}

function showIssueStatusModal(issueId, currentStatus) {
  const statuses = ['Open', 'In Progress', 'Resolved'];
  const html = `
  <div class="modal-header">
    <div class="modal-title">이슈 상태 변경</div>
    <button class="btn-icon btn-ghost" onclick="closeModal()"><i class="fas fa-times"></i></button>
  </div>
  <div class="modal-body">
    <div class="form-group">
      <label class="form-label">상태 선택</label>
      <select id="new-issue-status" class="form-control form-select">
        ${statuses.map(s => `<option value="${s}" ${s===currentStatus?'selected':''}>${s}</option>`).join('')}
      </select>
    </div>
  </div>
  <div class="modal-footer">
    <button class="btn btn-secondary" onclick="closeModal()">취소</button>
    <button class="btn btn-primary" id="save-issue-status">변경</button>
  </div>`;

  showModal(html);
  document.getElementById('save-issue-status').addEventListener('click', async () => {
    const newStatus = document.getElementById('new-issue-status').value;
    const r = await api.patch(`/issues/${issueId}/status`, { status: newStatus });
    if (r.ok) {
      const idx = App.issues.findIndex(i => i.issue_id === issueId);
      if (idx !== -1) App.issues[idx].status = newStatus;
      toast('상태가 변경되었습니다.', 'success');
      closeModal();
      renderIssuesPage();
    } else toast(r.error, 'error');
  });
}

function showIssueModal(issue = null, defaultTaskId = null) {
  const isEdit = !!issue;
  const html = `
  <div class="modal-header">
    <div class="modal-title">${isEdit ? '이슈 수정' : '이슈 추가'}</div>
    <button class="btn-icon btn-ghost" onclick="closeModal()"><i class="fas fa-times"></i></button>
  </div>
  <div class="modal-body">
    <div class="form-group">
      <label class="form-label">제목 <span style="color:#ef4444">*</span></label>
      <input id="i-title" class="form-control" placeholder="이슈 제목" value="${issue ? escHtml(issue.title) : ''}">
    </div>
    <div class="form-group">
      <label class="form-label">내용</label>
      <textarea id="i-desc" class="form-control" rows="3">${issue ? escHtml(issue.description||'') : ''}</textarea>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="form-group">
        <label class="form-label">중요도</label>
        <select id="i-priority" class="form-control form-select">
          <option value="Low" ${issue?.priority==='Low'?'selected':''}>Low</option>
          <option value="Medium" ${issue?.priority==='Medium'||!issue?'selected':''}>Medium</option>
          <option value="High" ${issue?.priority==='High'?'selected':''}>High</option>
          <option value="Critical" ${issue?.priority==='Critical'?'selected':''}>Critical</option>
        </select>
      </div>
      ${isEdit ? `<div class="form-group">
        <label class="form-label">상태</label>
        <select id="i-status" class="form-control form-select">
          <option value="Open" ${issue?.status==='Open'?'selected':''}>Open</option>
          <option value="In Progress" ${issue?.status==='In Progress'?'selected':''}>In Progress</option>
          <option value="Resolved" ${issue?.status==='Resolved'?'selected':''}>Resolved</option>
        </select>
      </div>` : '<div></div>'}
    </div>
    <div class="form-group">
      <label class="form-label">관련 업무</label>
      <select id="i-task" class="form-control form-select">
        <option value="">업무 연결 없음</option>
        ${App.tasks.map(t => `<option value="${t.task_id}" ${(issue?.task_id||defaultTaskId)===t.task_id?'selected':''}>${escHtml(t.title)}</option>`).join('')}
      </select>
    </div>
  </div>
  <div class="modal-footer">
    <button class="btn btn-secondary" onclick="closeModal()">취소</button>
    <button class="btn btn-primary" id="save-issue-btn">${isEdit ? '저장' : '추가'}</button>
  </div>`;

  showModal(html);
  document.getElementById('save-issue-btn').addEventListener('click', async () => {
    const title = document.getElementById('i-title').value.trim();
    if (!title) { toast('이슈 제목을 입력하세요.', 'error'); return; }

    const data = {
      title,
      description: document.getElementById('i-desc').value.trim() || null,
      priority: document.getElementById('i-priority').value,
      task_id: document.getElementById('i-task').value || null,
    };
    if (isEdit) data.status = document.getElementById('i-status').value;

    const r = isEdit ? await api.put(`/issues/${issue.issue_id}`, data) : await api.post('/issues', data);
    if (r.ok) {
      toast(isEdit ? '이슈가 수정되었습니다.' : '이슈가 추가되었습니다.', 'success');
      const ir = await api.get('/issues');
      if (ir.ok) App.issues = ir.data.issues;
      closeModal();
      if (App.currentPage === 'issues') renderIssuesPage();
      else if (App.currentPage === 'task-detail') renderTaskDetail();
    } else toast(r.error, 'error');
  });
}

// ===== Members Page =====
function renderMembersPage() {
  const content = document.getElementById('page-content');

  const AVATAR_COLORS = ['#6366f1','#ec4899','#f59e0b','#10b981','#3b82f6','#8b5cf6','#ef4444','#06b6d4','#84cc16','#f97316'];

  content.innerHTML = `
  <div style="display:flex;flex-direction:column;gap:16px">
    <div style="display:flex;align-items:center;justify-content:space-between">
      <div>
        <span style="font-size:14px;color:#64748b">전체 <strong>${App.users.length}</strong>명</span>
      </div>
      <button class="btn btn-primary" id="btn-add-member"><i class="fas fa-user-plus"></i> 팀원 추가</button>
    </div>

    <div class="card" style="overflow:hidden">
      ${App.users.length ? `
      <table class="table">
        <thead>
          <tr>
            <th>팀원</th>
            <th>이메일</th>
            <th>역할</th>
            <th>가입일</th>
            <th style="width:120px">액션</th>
          </tr>
        </thead>
        <tbody>
          ${App.users.map(u => `
            <tr ${App.currentUser?.user_id === u.user_id ? 'style="background:#f0f4ff"' : ''}>
              <td>
                <div style="display:flex;align-items:center;gap:10px">
                  ${avatarHtml(u.name, u.avatar_color)}
                  <div>
                    <div style="font-size:14px;font-weight:500">${escHtml(u.name)}</div>
                    ${App.currentUser?.user_id === u.user_id ? '<div style="font-size:11px;color:#6366f1;font-weight:500">현재 사용자</div>' : ''}
                  </div>
                </div>
              </td>
              <td style="font-size:13px;color:#374151">${escHtml(u.email)}</td>
              <td>
                <span class="badge" style="background:${u.role==='Admin'?'#ede9fe':'#f1f5f9'};color:${u.role==='Admin'?'#5b21b6':'#475569'}">${escHtml(u.role||'Member')}</span>
              </td>
              <td style="font-size:12px;color:#64748b">${formatDate(u.created_at)}</td>
              <td>
                <div class="table-action">
                  <button class="btn btn-ghost btn-icon btn-sm member-edit" data-id="${u.user_id}" title="수정"><i class="fas fa-edit"></i></button>
                  <button class="btn btn-ghost btn-icon btn-sm member-switch" data-id="${u.user_id}" title="이 사용자로 전환" style="color:#6366f1"><i class="fas fa-exchange-alt"></i></button>
                  <button class="btn btn-ghost btn-icon btn-sm member-delete" data-id="${u.user_id}" title="삭제" style="color:#ef4444"><i class="fas fa-trash"></i></button>
                </div>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>` : `
      <div class="empty-state" style="padding:60px">
        <i class="fas fa-users" style="font-size:48px;color:#cbd5e1;margin-bottom:16px"></i>
        <p style="font-size:16px;font-weight:500;margin-bottom:8px">등록된 팀원이 없습니다</p>
        <p style="font-size:13px;color:#94a3b8">팀원 추가 버튼을 클릭하여 첫 번째 팀원을 추가하세요.</p>
      </div>`}
    </div>
  </div>`;

  // 팀원 추가 버튼
  document.getElementById('btn-add-member').addEventListener('click', () => showMemberModal());

  // 수정 버튼
  document.querySelectorAll('.member-edit').forEach(el => {
    el.addEventListener('click', () => {
      const u = App.users.find(u => u.user_id === el.dataset.id);
      if (u) showMemberModal(u);
    });
  });

  // 사용자 전환 버튼
  document.querySelectorAll('.member-switch').forEach(el => {
    el.addEventListener('click', () => {
      const u = App.users.find(u => u.user_id === el.dataset.id);
      if (u) {
        App.currentUser = u;
        try { localStorage.setItem('tf_current_user_id', u.user_id); } catch(e) {}
        toast(`${u.name}으로 전환되었습니다.`, 'success');
        render();
      }
    });
  });

  // 삭제 버튼
  document.querySelectorAll('.member-delete').forEach(el => {
    el.addEventListener('click', async () => {
      const u = App.users.find(u => u.user_id === el.dataset.id);
      if (!u) return;
      if (App.users.length <= 1) { toast('마지막 팀원은 삭제할 수 없습니다.', 'error'); return; }
      if (!confirm(`"${u.name}"을(를) 삭제하시겠습니까?\n해당 팀원이 담당한 업무/일정의 담당자는 미지정으로 변경됩니다.`)) return;

      const r = await api.delete(`/users/${u.user_id}`);
      if (r.ok) {
        toast(`${u.name}이 삭제되었습니다.`, 'success');
        // 현재 사용자가 삭제되면 첫 번째 사용자로 전환
        if (App.currentUser?.user_id === u.user_id) {
          App.users = App.users.filter(us => us.user_id !== u.user_id);
          App.currentUser = App.users[0] || null;
          try { if (App.currentUser) localStorage.setItem('tf_current_user_id', App.currentUser.user_id); } catch(e) {}
        } else {
          App.users = App.users.filter(us => us.user_id !== u.user_id);
        }
        render();
      } else toast(r.error, 'error');
    });
  });
}

// ===== Member Modal (추가/수정) =====
function showMemberModal(user = null) {
  const isEdit = !!user;
  const AVATAR_COLORS = ['#6366f1','#ec4899','#f59e0b','#10b981','#3b82f6','#8b5cf6','#ef4444','#06b6d4','#84cc16','#f97316'];

  const html = `
  <div class="modal-header">
    <div class="modal-title">${isEdit ? '팀원 정보 수정' : '새 팀원 추가'}</div>
    <button class="btn-icon btn-ghost" onclick="closeModal()"><i class="fas fa-times"></i></button>
  </div>
  <div class="modal-body">
    <div style="display:flex;align-items:center;justify-content:center;margin-bottom:20px">
      <div id="avatar-preview" class="avatar" style="width:60px;height:60px;font-size:24px;background:${user?.avatar_color || AVATAR_COLORS[0]}">
        ${user ? user.name.charAt(0) : '?'}
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">이름 <span style="color:#ef4444">*</span></label>
      <input id="m-name" class="form-control" placeholder="이름을 입력하세요" value="${user ? escHtml(user.name) : ''}">
    </div>
    <div class="form-group">
      <label class="form-label">이메일 <span style="color:#ef4444">*</span></label>
      <input id="m-email" class="form-control" type="email" placeholder="email@example.com" value="${user ? escHtml(user.email) : ''}">
    </div>
    <div class="form-group">
      <label class="form-label">역할</label>
      <select id="m-role" class="form-control form-select">
        <option value="Member" ${(!user || user.role === 'Member') ? 'selected' : ''}>Member</option>
        <option value="Admin" ${user?.role === 'Admin' ? 'selected' : ''}>Admin</option>
        <option value="Viewer" ${user?.role === 'Viewer' ? 'selected' : ''}>Viewer</option>
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">아바타 색상</label>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">
        ${AVATAR_COLORS.map(c => `
          <div class="color-swatch ${(user?.avatar_color || AVATAR_COLORS[0]) === c ? 'selected' : ''}"
               data-color="${c}"
               style="width:28px;height:28px;border-radius:50%;background:${c};cursor:pointer;border:3px solid ${(user?.avatar_color || AVATAR_COLORS[0]) === c ? '#1e293b' : 'transparent'};transition:border-color 0.15s">
          </div>`).join('')}
      </div>
    </div>
  </div>
  <div class="modal-footer">
    <button class="btn btn-secondary" onclick="closeModal()">취소</button>
    <button class="btn btn-primary" id="save-member-btn">${isEdit ? '저장' : '추가'}</button>
  </div>`;

  showModal(html);

  let selectedColor = user?.avatar_color || AVATAR_COLORS[0];

  // 이름 입력 시 아바타 미리보기 업데이트
  document.getElementById('m-name').addEventListener('input', (e) => {
    const preview = document.getElementById('avatar-preview');
    preview.textContent = e.target.value ? e.target.value.charAt(0) : '?';
    preview.style.background = selectedColor;
  });

  // 색상 선택
  document.querySelectorAll('.color-swatch').forEach(el => {
    el.addEventListener('click', () => {
      selectedColor = el.dataset.color;
      document.querySelectorAll('.color-swatch').forEach(s => s.style.border = '3px solid transparent');
      el.style.border = '3px solid #1e293b';
      document.getElementById('avatar-preview').style.background = selectedColor;
    });
  });

  // 저장
  document.getElementById('save-member-btn').addEventListener('click', async () => {
    const name = document.getElementById('m-name').value.trim();
    const email = document.getElementById('m-email').value.trim();
    const role = document.getElementById('m-role').value;

    if (!name) { toast('이름을 입력하세요.', 'error'); return; }
    if (!email) { toast('이메일을 입력하세요.', 'error'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast('올바른 이메일 형식이 아닙니다.', 'error'); return; }

    const data = { name, email, role, avatar_color: selectedColor };
    const btn = document.getElementById('save-member-btn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span>';

    const r = isEdit ? await api.put(`/users/${user.user_id}`, data) : await api.post('/users', data);

    if (r.ok) {
      toast(isEdit ? '팀원 정보가 수정되었습니다.' : `${name}이(가) 팀에 추가되었습니다.`, 'success');
      // 사용자 목록 갱신
      const usersR = await api.get('/users');
      if (usersR.ok) {
        App.users = usersR.data.users;
        // 현재 사용자 정보가 수정됐으면 업데이트
        if (isEdit && App.currentUser?.user_id === user.user_id) {
          App.currentUser = App.users.find(u => u.user_id === user.user_id) || App.currentUser;
        }
        // 처음 추가하는 경우 현재 사용자로 설정
        if (!isEdit && !App.currentUser) {
          App.currentUser = App.users[0];
          try { localStorage.setItem('tf_current_user_id', App.currentUser.user_id); } catch(e) {}
        }
      }
      closeModal();
      render();
    } else {
      toast(r.error, 'error');
      btn.disabled = false;
      btn.innerHTML = isEdit ? '저장' : '추가';
    }
  });
}

// ===== App Init =====
async function init() {
  // 로딩 화면 표시
  document.getElementById('app').innerHTML = `
    <div style="display:flex;align-items:center;justify-content:center;height:100vh;flex-direction:column;gap:16px">
      <div style="font-size:28px;font-weight:700;color:#6366f1"><i class="fas fa-layer-group"></i> TeamFlow</div>
      <div class="spinner" style="width:32px;height:32px;border-width:3px"></div>
      <div style="font-size:13px;color:#94a3b8">데이터를 불러오는 중...</div>
    </div>`;

  // 데이터 로드
  await loadInitialData();

  // localStorage에서 마지막 사용자 복원
  let savedUserId = null;
  try { savedUserId = localStorage.getItem('tf_current_user_id'); } catch(e) {}

  if (savedUserId && App.users.find(u => u.user_id === savedUserId)) {
    App.currentUser = App.users.find(u => u.user_id === savedUserId);
  } else if (App.users.length > 0) {
    App.currentUser = App.users[0];
    try { localStorage.setItem('tf_current_user_id', App.currentUser.user_id); } catch(e) {}
  }

  navigate('dashboard');
}

window.navigate = navigate;
window.closeModal = closeModal;
init();
