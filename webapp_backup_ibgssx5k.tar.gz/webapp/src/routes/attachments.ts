// src/routes/attachments.ts
import { Hono } from 'hono'
import { authMiddleware } from '../middleware/auth'
import { generateId, now } from '../utils'
import type { Env, Variables } from '../middleware/auth'

const attachments = new Hono<{ Bindings: Env; Variables: Variables }>()

attachments.use('/*', authMiddleware)

// POST /api/tasks/:id/attachments
// 실제 파일 저장은 Base64 인코딩으로 처리 (Cloudflare Workers 환경)
attachments.post('/tasks/:id/attachments', async (c) => {
  const taskId = c.req.param('id')
  const db = c.env.DB
  const userId = c.get('userId')
  
  const task = await db.prepare('SELECT task_id FROM tasks WHERE task_id = ? AND deleted_at IS NULL').bind(taskId).first<any>()
  if (!task) return c.json({ error: '업무를 찾을 수 없습니다.' }, 404)

  const body = await c.req.json().catch(() => null)
  if (!body?.file_name || !body?.file_data) {
    return c.json({ error: '파일 이름과 데이터가 필요합니다.' }, 400)
  }

  // 파일 크기 제한 (10MB)
  const MAX_SIZE = 10 * 1024 * 1024
  const fileSize = body.file_size || 0
  if (fileSize > MAX_SIZE) {
    return c.json({ error: '파일 크기는 10MB를 초과할 수 없습니다.' }, 400)
  }

  // 허용 파일 타입
  const allowedTypes = ['image/', 'application/pdf', 'text/', 'application/msword', 
    'application/vnd.', 'application/zip', 'application/x-zip']
  const fileType = body.file_type || ''
  
  const attachmentId = generateId()
  // 실제 환경에서는 R2에 저장, 개발 환경에서는 Base64 URL로 저장
  const fileUrl = body.file_data.startsWith('data:') ? body.file_data : `data:${fileType};base64,${body.file_data}`

  await db.prepare(`
    INSERT INTO attachments (attachment_id, task_id, file_name, file_url, file_size, file_type, uploaded_by, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(attachmentId, taskId, body.file_name, fileUrl, fileSize, fileType, userId, now()).run()

  const attachment = await db.prepare(`
    SELECT a.*, u.name as uploader_name
    FROM attachments a LEFT JOIN users u ON a.uploaded_by = u.user_id
    WHERE a.attachment_id = ?
  `).bind(attachmentId).first<any>()

  return c.json({ attachment }, 201)
})

// GET /api/tasks/:id/attachments
attachments.get('/tasks/:id/attachments', async (c) => {
  const db = c.env.DB
  const result = await db.prepare(`
    SELECT a.attachment_id, a.file_name, a.file_size, a.file_type, a.created_at, u.name as uploader_name
    FROM attachments a LEFT JOIN users u ON a.uploaded_by = u.user_id
    WHERE a.task_id = ?
    ORDER BY a.created_at DESC
  `).bind(c.req.param('id')).all<any>()
  
  return c.json({ attachments: result.results })
})

// GET /api/attachments/:id (다운로드용)
attachments.get('/attachments/:id', async (c) => {
  const db = c.env.DB
  const attachment = await db.prepare(
    'SELECT * FROM attachments WHERE attachment_id = ?'
  ).bind(c.req.param('id')).first<any>()
  
  if (!attachment) return c.json({ error: '파일을 찾을 수 없습니다.' }, 404)
  return c.json({ attachment })
})

// DELETE /api/attachments/:id
attachments.delete('/attachments/:id', async (c) => {
  const attachmentId = c.req.param('id')
  const db = c.env.DB
  
  const existing = await db.prepare('SELECT * FROM attachments WHERE attachment_id = ?').bind(attachmentId).first<any>()
  if (!existing) return c.json({ error: '파일을 찾을 수 없습니다.' }, 404)

  await db.prepare('DELETE FROM attachments WHERE attachment_id = ?').bind(attachmentId).run()
  return c.json({ success: true })
})

export default attachments
