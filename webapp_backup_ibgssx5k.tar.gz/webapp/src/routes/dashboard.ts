// src/routes/dashboard.ts
import { Hono } from 'hono'
import { authMiddleware } from '../middleware/auth'
import { isDelayed } from '../utils'
import type { Env, Variables } from '../middleware/auth'

const dashboard = new Hono<{ Bindings: Env; Variables: Variables }>()

dashboard.use('/*', authMiddleware)

// GET /api/dashboard/summary
dashboard.get('/summary', async (c) => {
  const db = c.env.DB
  const { assignee_id, start, end } = c.req.query()
  
  let taskFilter = "deleted_at IS NULL"
  const params: any[] = []
  
  if (assignee_id) { taskFilter += ' AND assignee_id = ?'; params.push(assignee_id) }
  if (start) { taskFilter += ' AND (due_date IS NULL OR due_date >= ?)'; params.push(start) }
  if (end) { taskFilter += ' AND (due_date IS NULL OR due_date <= ?)'; params.push(end) }

  // 전체 업무 통계
  const allTasks = await db.prepare(`SELECT * FROM tasks WHERE ${taskFilter}`).bind(...params).all<any>()
  const tasks = allTasks.results
  
  const total = tasks.length
  const done = tasks.filter(t => t.status === 'Done').length
  const inProgress = tasks.filter(t => t.status === 'In Progress').length
  const todo = tasks.filter(t => t.status === 'To-do').length
  const delayed = tasks.filter(t => isDelayed(t.due_date, t.status)).length
  
  // 마감 임박 (3일 이내)
  const threeDaysLater = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().replace('T', ' ').substring(0, 19)
  const today = new Date().toISOString().replace('T', ' ').substring(0, 19)
  const dueSoon = tasks.filter(t => 
    t.due_date && t.status !== 'Done' && 
    t.due_date >= today && t.due_date <= threeDaysLater
  ).length
  
  const completionRate = total > 0 ? Math.round((done / total) * 100) : 0
  const delayRate = total > 0 ? Math.round((delayed / total) * 100) : 0

  // 미해결 이슈
  const issueResult = await db.prepare(
    "SELECT COUNT(*) as cnt FROM issues WHERE status != 'Resolved'"
  ).first<any>()
  const unresolvedIssues = issueResult?.cnt || 0

  // Critical 이슈
  const criticalIssueResult = await db.prepare(
    "SELECT COUNT(*) as cnt FROM issues WHERE priority = 'Critical' AND status != 'Resolved'"
  ).first<any>()
  const criticalIssues = criticalIssueResult?.cnt || 0

  return c.json({
    summary: {
      total,
      done,
      in_progress: inProgress,
      todo,
      delayed,
      due_soon: dueSoon,
      completion_rate: completionRate,
      delay_rate: delayRate,
      unresolved_issues: unresolvedIssues,
      critical_issues: criticalIssues
    }
  })
})

// GET /api/dashboard/risks
dashboard.get('/risks', async (c) => {
  const db = c.env.DB
  const today = new Date().toISOString().replace('T', ' ').substring(0, 19)

  // 1. 마감일 초과 + 미완료 업무
  const overdueResult = await db.prepare(`
    SELECT t.*, u.name as assignee_name, u.avatar_color as assignee_color
    FROM tasks t
    LEFT JOIN users u ON t.assignee_id = u.user_id
    WHERE t.deleted_at IS NULL AND t.status != 'Done' AND t.due_date IS NOT NULL AND t.due_date < ?
    ORDER BY t.due_date ASC
    LIMIT 10
  `).bind(today).all<any>()

  // 2. Critical 이슈와 연관된 업무
  const criticalIssueTasksResult = await db.prepare(`
    SELECT DISTINCT t.*, u.name as assignee_name, u.avatar_color as assignee_color,
           i.title as issue_title
    FROM tasks t
    LEFT JOIN users u ON t.assignee_id = u.user_id
    JOIN issues i ON i.task_id = t.task_id
    WHERE t.deleted_at IS NULL AND i.priority = 'Critical' AND i.status != 'Resolved'
    ORDER BY t.due_date ASC
    LIMIT 10
  `).all<any>()

  // 3. 선행 업무 미완료로 차단된 업무
  const blockedResult = await db.prepare(`
    SELECT t.*, u.name as assignee_name, u.avatar_color as assignee_color,
           dt.title as dependency_title, dt.status as dependency_status
    FROM tasks t
    LEFT JOIN users u ON t.assignee_id = u.user_id
    LEFT JOIN tasks dt ON t.dependency_task_id = dt.task_id
    WHERE t.deleted_at IS NULL AND t.dependency_task_id IS NOT NULL 
      AND t.status != 'Done' AND dt.status != 'Done'
    ORDER BY t.due_date ASC
    LIMIT 10
  `).all<any>()

  // 지연 표시 추가
  const overdue = overdueResult.results.map(t => ({ ...t, risk_type: 'overdue', is_delayed: 1 }))
  const criticalIssue = criticalIssueTasksResult.results.map(t => ({ ...t, risk_type: 'critical_issue', is_delayed: isDelayed(t.due_date, t.status) ? 1 : 0 }))
  const blocked = blockedResult.results.map(t => ({ ...t, risk_type: 'blocked', is_delayed: isDelayed(t.due_date, t.status) ? 1 : 0 }))

  // 지연된 업무 목록
  const allTasks = await db.prepare(`
    SELECT t.*, u.name as assignee_name, u.avatar_color as assignee_color
    FROM tasks t LEFT JOIN users u ON t.assignee_id = u.user_id
    WHERE t.deleted_at IS NULL AND t.status != 'Done' AND t.due_date IS NOT NULL
    ORDER BY t.due_date ASC
  `).all<any>()
  
  const delayedTasks = allTasks.results.filter(t => isDelayed(t.due_date, t.status)).map(t => ({...t, is_delayed: 1}))

  // 최근 Critical/High 이슈
  const recentIssues = await db.prepare(`
    SELECT i.*, t.title as task_title, u.name as creator_name
    FROM issues i
    LEFT JOIN tasks t ON i.task_id = t.task_id
    LEFT JOIN users u ON i.created_by = u.user_id
    WHERE i.status != 'Resolved' AND i.priority IN ('Critical', 'High')
    ORDER BY CASE i.priority WHEN 'Critical' THEN 1 ELSE 2 END, i.created_at DESC
    LIMIT 5
  `).all<any>()

  return c.json({
    risks: {
      overdue_tasks: overdue,
      critical_issue_tasks: criticalIssue,
      blocked_tasks: blocked,
      delayed_tasks: delayedTasks.slice(0, 10),
      recent_critical_issues: recentIssues.results
    }
  })
})

export default dashboard
