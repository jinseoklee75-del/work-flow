// src/routes/comments.ts
import { Hono } from 'hono'
import { authMiddleware } from '../middleware/auth'
import { generateId, now } from '../utils'
import type { Env, Variables } from '../middleware/auth'

const comments = new Hono<{ Bindings: Env; Variables: Variables }>()

comments.use('/*', authMiddleware)

// GET /api/tasks/:id/comments
comments.get('/tasks/:id/comments', async (c) => {
  const db = c.env.DB
  const result = await db.prepare(`
    SELECT c.*, u.name as user_name, u.avatar_color
    FROM comments c
    LEFT JOIN users u ON c.user_id = u.user_id
    WHERE c.task_id = ?
    ORDER BY c.created_at ASC
  `).bind(c.req.param('id')).all<any>()
  
  return c.json({ comments: result.results })
})

// POST /api/tasks/:id/comments
comments.post('/tasks/:id/comments', async (c) => {
  const taskId = c.req.param('id')
  const body = await c.req.json().catch(() => null)
  if (!body?.content?.trim()) return c.json({ error: '댓글 내용은 필수입니다.' }, 400)

  const db = c.env.DB
  const userId = c.get('userId')
  
  // 업무 존재 확인
  const task = await db.prepare('SELECT task_id FROM tasks WHERE task_id = ? AND deleted_at IS NULL').bind(taskId).first<any>()
  if (!task) return c.json({ error: '업무를 찾을 수 없습니다.' }, 404)

  const commentId = generateId()
  await db.prepare(
    'INSERT INTO comments (comment_id, task_id, user_id, content, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).bind(commentId, taskId, userId, body.content.trim(), now(), now()).run()

  const comment = await db.prepare(`
    SELECT c.*, u.name as user_name, u.avatar_color
    FROM comments c LEFT JOIN users u ON c.user_id = u.user_id
    WHERE c.comment_id = ?
  `).bind(commentId).first<any>()

  return c.json({ comment }, 201)
})

// PUT /api/comments/:id
comments.put('/comments/:id', async (c) => {
  const commentId = c.req.param('id')
  const db = c.env.DB
  const userId = c.get('userId')
  
  const existing = await db.prepare('SELECT * FROM comments WHERE comment_id = ?').bind(commentId).first<any>()
  if (!existing) return c.json({ error: '댓글을 찾을 수 없습니다.' }, 404)
  if (existing.user_id !== userId) return c.json({ error: '본인의 댓글만 수정할 수 있습니다.' }, 403)

  const body = await c.req.json().catch(() => null)
  if (!body?.content?.trim()) return c.json({ error: '댓글 내용은 필수입니다.' }, 400)

  await db.prepare('UPDATE comments SET content = ?, updated_at = ? WHERE comment_id = ?').bind(body.content.trim(), now(), commentId).run()

  const comment = await db.prepare(`
    SELECT c.*, u.name as user_name, u.avatar_color
    FROM comments c LEFT JOIN users u ON c.user_id = u.user_id
    WHERE c.comment_id = ?
  `).bind(commentId).first<any>()
  
  return c.json({ comment })
})

// DELETE /api/comments/:id
comments.delete('/comments/:id', async (c) => {
  const commentId = c.req.param('id')
  const db = c.env.DB
  const userId = c.get('userId')
  
  const existing = await db.prepare('SELECT * FROM comments WHERE comment_id = ?').bind(commentId).first<any>()
  if (!existing) return c.json({ error: '댓글을 찾을 수 없습니다.' }, 404)
  if (existing.user_id !== userId) return c.json({ error: '본인의 댓글만 삭제할 수 있습니다.' }, 403)

  await db.prepare('DELETE FROM comments WHERE comment_id = ?').bind(commentId).run()
  return c.json({ success: true })
})

export default comments
