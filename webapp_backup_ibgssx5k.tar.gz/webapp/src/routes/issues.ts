// src/routes/issues.ts
import { Hono } from 'hono'
import { authMiddleware } from '../middleware/auth'
import { generateId, now } from '../utils'
import type { Env, Variables } from '../middleware/auth'

const issues = new Hono<{ Bindings: Env; Variables: Variables }>()

issues.use('/*', authMiddleware)

async function logActivity(db: D1Database, params: {
  entityType: string, entityId: string, action: string,
  before?: any, after?: any, actedBy: string
}) {
  await db.prepare(
    'INSERT INTO activity_logs (log_id, entity_type, entity_id, action, before_value, after_value, acted_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).bind(
    generateId(), params.entityType, params.entityId, params.action,
    params.before ? JSON.stringify(params.before) : null,
    params.after ? JSON.stringify(params.after) : null,
    params.actedBy, now()
  ).run()
}

// GET /api/issues
issues.get('/', async (c) => {
  const db = c.env.DB
  const { status, priority, task_id } = c.req.query()
  
  let query = `
    SELECT i.*,
           u.name as creator_name, u.avatar_color as creator_color,
           t.title as task_title
    FROM issues i
    LEFT JOIN users u ON i.created_by = u.user_id
    LEFT JOIN tasks t ON i.task_id = t.task_id
    WHERE 1=1
  `
  const params: any[] = []

  if (status) { query += ' AND i.status = ?'; params.push(status) }
  if (priority) { query += ' AND i.priority = ?'; params.push(priority) }
  if (task_id) { query += ' AND i.task_id = ?'; params.push(task_id) }
  
  query += ' ORDER BY CASE i.priority WHEN \'Critical\' THEN 1 WHEN \'High\' THEN 2 WHEN \'Medium\' THEN 3 ELSE 4 END, i.created_at DESC'
  
  const result = await db.prepare(query).bind(...params).all<any>()
  return c.json({ issues: result.results })
})

// POST /api/issues
issues.post('/', async (c) => {
  const body = await c.req.json().catch(() => null)
  if (!body?.title?.trim()) return c.json({ error: '이슈 제목은 필수입니다.' }, 400)

  const db = c.env.DB
  const userId = c.get('userId')
  const issueId = generateId()
  
  await db.prepare(`
    INSERT INTO issues (issue_id, title, description, task_id, status, priority, created_by, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    issueId, body.title.trim(), body.description || null,
    body.task_id || null, 'Open',
    body.priority || 'Medium',
    userId, now(), now()
  ).run()

  await logActivity(db, {
    entityType: 'issue', entityId: issueId, action: 'create',
    after: { title: body.title, status: 'Open' }, actedBy: userId
  })

  const issue = await db.prepare(`
    SELECT i.*, u.name as creator_name, t.title as task_title
    FROM issues i LEFT JOIN users u ON i.created_by = u.user_id LEFT JOIN tasks t ON i.task_id = t.task_id
    WHERE i.issue_id = ?
  `).bind(issueId).first<any>()

  return c.json({ issue }, 201)
})

// GET /api/issues/:id
issues.get('/:id', async (c) => {
  const db = c.env.DB
  const issue = await db.prepare(`
    SELECT i.*, u.name as creator_name, u.avatar_color as creator_color, t.title as task_title
    FROM issues i
    LEFT JOIN users u ON i.created_by = u.user_id
    LEFT JOIN tasks t ON i.task_id = t.task_id
    WHERE i.issue_id = ?
  `).bind(c.req.param('id')).first<any>()
  
  if (!issue) return c.json({ error: '이슈를 찾을 수 없습니다.' }, 404)
  return c.json({ issue })
})

// PUT /api/issues/:id
issues.put('/:id', async (c) => {
  const issueId = c.req.param('id')
  const db = c.env.DB
  const userId = c.get('userId')
  
  const existing = await db.prepare('SELECT * FROM issues WHERE issue_id = ?').bind(issueId).first<any>()
  if (!existing) return c.json({ error: '이슈를 찾을 수 없습니다.' }, 404)

  const body = await c.req.json().catch(() => null)
  if (!body) return c.json({ error: '유효하지 않은 요청입니다.' }, 400)

  await db.prepare(`
    UPDATE issues SET title=?, description=?, task_id=?, status=?, priority=?, updated_at=?
    WHERE issue_id=?
  `).bind(
    body.title?.trim() ?? existing.title,
    body.description !== undefined ? body.description : existing.description,
    body.task_id !== undefined ? body.task_id : existing.task_id,
    body.status ?? existing.status,
    body.priority ?? existing.priority,
    now(), issueId
  ).run()

  if (body.status && body.status !== existing.status) {
    await logActivity(db, { entityType: 'issue', entityId: issueId, action: 'status_change', before: { status: existing.status }, after: { status: body.status }, actedBy: userId })
  }
  await logActivity(db, { entityType: 'issue', entityId: issueId, action: 'update', before: existing, after: body, actedBy: userId })

  const issue = await db.prepare('SELECT * FROM issues WHERE issue_id = ?').bind(issueId).first<any>()
  return c.json({ issue })
})

// DELETE /api/issues/:id
issues.delete('/:id', async (c) => {
  const issueId = c.req.param('id')
  const db = c.env.DB
  const userId = c.get('userId')
  
  const existing = await db.prepare('SELECT issue_id FROM issues WHERE issue_id = ?').bind(issueId).first<any>()
  if (!existing) return c.json({ error: '이슈를 찾을 수 없습니다.' }, 404)

  await db.prepare('DELETE FROM issues WHERE issue_id = ?').bind(issueId).run()
  await logActivity(db, { entityType: 'issue', entityId: issueId, action: 'delete', actedBy: userId })
  
  return c.json({ success: true })
})

// PATCH /api/issues/:id/status
issues.patch('/:id/status', async (c) => {
  const issueId = c.req.param('id')
  const db = c.env.DB
  const userId = c.get('userId')
  
  const body = await c.req.json().catch(() => null)
  if (!body?.status) return c.json({ error: 'status 값이 필요합니다.' }, 400)
  
  const validStatuses = ['Open', 'In Progress', 'Resolved']
  if (!validStatuses.includes(body.status)) {
    return c.json({ error: '유효하지 않은 상태값입니다.' }, 400)
  }

  const existing = await db.prepare('SELECT * FROM issues WHERE issue_id = ?').bind(issueId).first<any>()
  if (!existing) return c.json({ error: '이슈를 찾을 수 없습니다.' }, 404)

  await db.prepare('UPDATE issues SET status = ?, updated_at = ? WHERE issue_id = ?').bind(body.status, now(), issueId).run()
  
  await logActivity(db, { entityType: 'issue', entityId: issueId, action: 'status_change', before: { status: existing.status }, after: { status: body.status }, actedBy: userId })
  
  return c.json({ success: true, status: body.status })
})

export default issues
