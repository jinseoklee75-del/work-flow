// src/routes/auth.ts
// 로그인 제거 - /api/auth/me 로 현재 사용자 정보 조회만 지원
import { Hono } from 'hono'
import type { Env, Variables } from '../middleware/auth'

const auth = new Hono<{ Bindings: Env; Variables: Variables }>()

// GET /api/auth/me - X-User-Id 헤더 기반으로 현재 사용자 반환
auth.get('/me', async (c) => {
  const db = c.env.DB
  const headerUserId = c.req.header('X-User-Id')

  let user: any = null

  if (headerUserId) {
    user = await db.prepare(
      'SELECT user_id, name, email, role, avatar_color, created_at FROM users WHERE user_id = ?'
    ).bind(headerUserId).first()
  }

  if (!user) {
    user = await db.prepare(
      'SELECT user_id, name, email, role, avatar_color, created_at FROM users ORDER BY created_at LIMIT 1'
    ).first()
  }

  if (!user) {
    return c.json({ user: null })
  }

  return c.json({ user })
})

export default auth
