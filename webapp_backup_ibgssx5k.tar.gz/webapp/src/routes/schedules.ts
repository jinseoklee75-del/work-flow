// src/routes/schedules.ts
import { Hono } from 'hono'
import { authMiddleware } from '../middleware/auth'
import { generateId, now } from '../utils'
import type { Env, Variables } from '../middleware/auth'

const schedules = new Hono<{ Bindings: Env; Variables: Variables }>()

schedules.use('/*', authMiddleware)

async function logActivity(db: D1Database, params: {
  entityType: string, entityId: string, action: string,
  before?: any, after?: any, actedBy: string
}) {
  await db.prepare(
    'INSERT INTO activity_logs (log_id, entity_type, entity_id, action, before_value, after_value, acted_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).bind(
    generateId(), params.entityType, params.entityId, params.action,
    params.before ? JSON.stringify(params.before) : null,
    params.after ? JSON.stringify(params.after) : null,
    params.actedBy, now()
  ).run()
}

// GET /api/schedules
schedules.get('/', async (c) => {
  const db = c.env.DB
  const { start, end, type, owner_id } = c.req.query()
  
  let query = `
    SELECT s.*,
           u.name as owner_name, u.avatar_color as owner_color,
           t.title as task_title
    FROM schedules s
    LEFT JOIN users u ON s.owner_id = u.user_id
    LEFT JOIN tasks t ON s.related_task_id = t.task_id
    WHERE 1=1
  `
  const params: any[] = []

  if (start) { query += ' AND s.end_date >= ?'; params.push(start) }
  if (end) { query += ' AND s.start_date <= ?'; params.push(end) }
  if (type) { query += ' AND s.type = ?'; params.push(type) }
  if (owner_id) { query += ' AND s.owner_id = ?'; params.push(owner_id) }
  
  query += ' ORDER BY s.start_date ASC'
  
  const result = await db.prepare(query).bind(...params).all<any>()
  return c.json({ schedules: result.results })
})

// POST /api/schedules
schedules.post('/', async (c) => {
  const body = await c.req.json().catch(() => null)
  if (!body?.title?.trim()) return c.json({ error: '일정명은 필수입니다.' }, 400)
  if (!body?.start_date) return c.json({ error: '시작일시는 필수입니다.' }, 400)
  if (!body?.end_date) return c.json({ error: '종료일시는 필수입니다.' }, 400)
  
  // 시작일이 종료일보다 늦은 경우 저장 불가
  if (new Date(body.start_date) > new Date(body.end_date)) {
    return c.json({ error: '시작일시는 종료일시보다 이전이어야 합니다.' }, 400)
  }

  const db = c.env.DB
  const userId = c.get('userId')
  
  // 일정 중복 체크
  const ownerId = body.owner_id || userId
  const overlap = await db.prepare(`
    SELECT COUNT(*) as cnt FROM schedules 
    WHERE owner_id = ? AND NOT (end_date <= ? OR start_date >= ?)
  `).bind(ownerId, body.start_date, body.end_date).first<any>()
  
  const hasOverlap = overlap?.cnt > 0
  
  const scheduleId = generateId()
  await db.prepare(`
    INSERT INTO schedules (schedule_id, title, type, start_date, end_date, related_task_id, owner_id, description, created_by, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    scheduleId, body.title.trim(), body.type || 'personal',
    body.start_date, body.end_date,
    body.related_task_id || null, ownerId,
    body.description || null, userId, now(), now()
  ).run()

  await logActivity(db, {
    entityType: 'schedule', entityId: scheduleId, action: 'create',
    after: { title: body.title }, actedBy: userId
  })

  const schedule = await db.prepare(
    'SELECT * FROM schedules WHERE schedule_id = ?'
  ).bind(scheduleId).first<any>()

  return c.json({ schedule, warning: hasOverlap ? '동일 시간대에 다른 일정이 있습니다.' : null }, 201)
})

// GET /api/schedules/:id
schedules.get('/:id', async (c) => {
  const db = c.env.DB
  const schedule = await db.prepare(`
    SELECT s.*, u.name as owner_name, u.avatar_color as owner_color, t.title as task_title
    FROM schedules s
    LEFT JOIN users u ON s.owner_id = u.user_id
    LEFT JOIN tasks t ON s.related_task_id = t.task_id
    WHERE s.schedule_id = ?
  `).bind(c.req.param('id')).first<any>()
  
  if (!schedule) return c.json({ error: '일정을 찾을 수 없습니다.' }, 404)
  return c.json({ schedule })
})

// PUT /api/schedules/:id
schedules.put('/:id', async (c) => {
  const scheduleId = c.req.param('id')
  const db = c.env.DB
  const userId = c.get('userId')
  
  const existing = await db.prepare('SELECT * FROM schedules WHERE schedule_id = ?').bind(scheduleId).first<any>()
  if (!existing) return c.json({ error: '일정을 찾을 수 없습니다.' }, 404)

  const body = await c.req.json().catch(() => null)
  if (!body) return c.json({ error: '유효하지 않은 요청입니다.' }, 400)

  const startDate = body.start_date ?? existing.start_date
  const endDate = body.end_date ?? existing.end_date
  
  if (new Date(startDate) > new Date(endDate)) {
    return c.json({ error: '시작일시는 종료일시보다 이전이어야 합니다.' }, 400)
  }

  // 중복 체크 (자신 제외)
  const ownerId = body.owner_id ?? existing.owner_id
  const overlap = await db.prepare(`
    SELECT COUNT(*) as cnt FROM schedules 
    WHERE owner_id = ? AND schedule_id != ? AND NOT (end_date <= ? OR start_date >= ?)
  `).bind(ownerId, scheduleId, startDate, endDate).first<any>()
  
  const hasOverlap = overlap?.cnt > 0

  await db.prepare(`
    UPDATE schedules SET title=?, type=?, start_date=?, end_date=?, related_task_id=?, owner_id=?, description=?, updated_at=?
    WHERE schedule_id=?
  `).bind(
    body.title?.trim() ?? existing.title,
    body.type ?? existing.type,
    startDate, endDate,
    body.related_task_id !== undefined ? body.related_task_id : existing.related_task_id,
    ownerId,
    body.description !== undefined ? body.description : existing.description,
    now(), scheduleId
  ).run()

  await logActivity(db, { entityType: 'schedule', entityId: scheduleId, action: 'update', before: existing, after: body, actedBy: userId })

  const schedule = await db.prepare('SELECT * FROM schedules WHERE schedule_id = ?').bind(scheduleId).first<any>()
  return c.json({ schedule, warning: hasOverlap ? '동일 시간대에 다른 일정이 있습니다.' : null })
})

// DELETE /api/schedules/:id
schedules.delete('/:id', async (c) => {
  const scheduleId = c.req.param('id')
  const db = c.env.DB
  const userId = c.get('userId')
  
  const existing = await db.prepare('SELECT schedule_id, type FROM schedules WHERE schedule_id = ?').bind(scheduleId).first<any>()
  if (!existing) return c.json({ error: '일정을 찾을 수 없습니다.' }, 404)
  
  await db.prepare('DELETE FROM schedules WHERE schedule_id = ?').bind(scheduleId).run()
  
  await logActivity(db, { entityType: 'schedule', entityId: scheduleId, action: 'delete', actedBy: userId })
  
  return c.json({ success: true })
})

export default schedules
