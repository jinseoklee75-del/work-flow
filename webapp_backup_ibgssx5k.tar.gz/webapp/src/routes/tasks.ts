// src/routes/tasks.ts
import { Hono } from 'hono'
import { authMiddleware } from '../middleware/auth'
import { generateId, now, isDelayed, jsonSafe } from '../utils'
import type { Env, Variables } from '../middleware/auth'

const tasks = new Hono<{ Bindings: Env; Variables: Variables }>()

tasks.use('/*', authMiddleware)

async function logActivity(db: D1Database, params: {
  entityType: string, entityId: string, action: string,
  before?: any, after?: any, actedBy: string
}) {
  await db.prepare(
    'INSERT INTO activity_logs (log_id, entity_type, entity_id, action, before_value, after_value, acted_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).bind(
    generateId(), params.entityType, params.entityId, params.action,
    params.before ? jsonSafe(params.before) : null,
    params.after ? jsonSafe(params.after) : null,
    params.actedBy, now()
  ).run()
}

async function autoCreateSchedule(db: D1Database, task: any, userId: string) {
  if (!task.due_date) return
  
  // 기존 자동 생성 일정 확인
  const existing = await db.prepare(
    'SELECT schedule_id FROM schedules WHERE related_task_id = ? AND type = ?'
  ).bind(task.task_id, 'task').first<any>()

  if (existing) {
    await db.prepare(
      'UPDATE schedules SET title = ?, start_date = ?, end_date = ?, updated_at = ? WHERE schedule_id = ?'
    ).bind(task.title + ' 마감', task.due_date, task.due_date, now(), existing.schedule_id).run()
  } else {
    const scheduleId = generateId()
    await db.prepare(
      'INSERT INTO schedules (schedule_id, title, type, start_date, end_date, related_task_id, owner_id, description, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).bind(
      scheduleId, task.title + ' 마감', 'task',
      task.due_date, task.due_date, task.task_id,
      task.assignee_id || userId, '업무 자동 생성 일정',
      userId, now(), now()
    ).run()
  }
}

// GET /api/tasks
tasks.get('/', async (c) => {
  const db = c.env.DB
  const { status, priority, assignee_id, search } = c.req.query()
  
  let query = `
    SELECT t.*, 
           u_a.name as assignee_name, u_a.avatar_color as assignee_color,
           u_c.name as creator_name,
           dt.title as dependency_title
    FROM tasks t
    LEFT JOIN users u_a ON t.assignee_id = u_a.user_id
    LEFT JOIN users u_c ON t.created_by = u_c.user_id
    LEFT JOIN tasks dt ON t.dependency_task_id = dt.task_id
    WHERE t.deleted_at IS NULL
  `
  const params: any[] = []

  if (status) { query += ' AND t.status = ?'; params.push(status) }
  if (priority) { query += ' AND t.priority = ?'; params.push(priority) }
  if (assignee_id) { query += ' AND t.assignee_id = ?'; params.push(assignee_id) }
  if (search) { query += ' AND (t.title LIKE ? OR t.description LIKE ?)'; params.push(`%${search}%`, `%${search}%`) }
  
  query += ' ORDER BY t.created_at DESC'
  
  const result = await db.prepare(query).bind(...params).all<any>()
  
  // 지연 여부 실시간 계산
  const tasks = result.results.map(task => ({
    ...task,
    is_delayed: isDelayed(task.due_date, task.status) ? 1 : 0
  }))
  
  return c.json({ tasks })
})

// POST /api/tasks
tasks.post('/', async (c) => {
  const body = await c.req.json().catch(() => null)
  if (!body?.title?.trim()) {
    return c.json({ error: '업무명은 필수입니다.' }, 400)
  }

  const db = c.env.DB
  const userId = c.get('userId')
  const taskId = generateId()
  
  await db.prepare(`
    INSERT INTO tasks (task_id, title, description, assignee_id, status, priority, due_date, dependency_task_id, created_by, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    taskId,
    body.title.trim(),
    body.description || null,
    body.assignee_id || null,
    body.status || 'To-do',
    body.priority || 'Medium',
    body.due_date || null,
    body.dependency_task_id || null,
    userId, now(), now()
  ).run()

  // 자동 일정 생성
  if (body.due_date) {
    await autoCreateSchedule(db, { task_id: taskId, title: body.title, due_date: body.due_date, assignee_id: body.assignee_id }, userId)
  }

  // 활동 로그
  await logActivity(db, {
    entityType: 'task', entityId: taskId, action: 'create',
    after: { title: body.title, status: body.status || 'To-do' }, actedBy: userId
  })

  const task = await db.prepare(`
    SELECT t.*, u_a.name as assignee_name, u_a.avatar_color as assignee_color
    FROM tasks t LEFT JOIN users u_a ON t.assignee_id = u_a.user_id
    WHERE t.task_id = ?
  `).bind(taskId).first<any>()

  return c.json({ task }, 201)
})

// GET /api/tasks/:id
tasks.get('/:id', async (c) => {
  const db = c.env.DB
  const task = await db.prepare(`
    SELECT t.*, 
           u_a.name as assignee_name, u_a.avatar_color as assignee_color,
           u_c.name as creator_name,
           dt.title as dependency_title, dt.status as dependency_status
    FROM tasks t
    LEFT JOIN users u_a ON t.assignee_id = u_a.user_id
    LEFT JOIN users u_c ON t.created_by = u_c.user_id
    LEFT JOIN tasks dt ON t.dependency_task_id = dt.task_id
    WHERE t.task_id = ? AND t.deleted_at IS NULL
  `).bind(c.req.param('id')).first<any>()

  if (!task) return c.json({ error: '업무를 찾을 수 없습니다.' }, 404)
  
  task.is_delayed = isDelayed(task.due_date, task.status) ? 1 : 0
  return c.json({ task })
})

// PUT /api/tasks/:id
tasks.put('/:id', async (c) => {
  const taskId = c.req.param('id')
  const db = c.env.DB
  const userId = c.get('userId')
  
  const existing = await db.prepare('SELECT * FROM tasks WHERE task_id = ? AND deleted_at IS NULL').bind(taskId).first<any>()
  if (!existing) return c.json({ error: '업무를 찾을 수 없습니다.' }, 404)

  const body = await c.req.json().catch(() => null)
  if (!body) return c.json({ error: '유효하지 않은 요청입니다.' }, 400)
  if (body.title !== undefined && !body.title?.trim()) {
    return c.json({ error: '업무명은 필수입니다.' }, 400)
  }

  const updated = {
    title: body.title?.trim() ?? existing.title,
    description: body.description !== undefined ? body.description : existing.description,
    assignee_id: body.assignee_id !== undefined ? body.assignee_id : existing.assignee_id,
    status: body.status ?? existing.status,
    priority: body.priority ?? existing.priority,
    due_date: body.due_date !== undefined ? body.due_date : existing.due_date,
    dependency_task_id: body.dependency_task_id !== undefined ? body.dependency_task_id : existing.dependency_task_id,
  }

  await db.prepare(`
    UPDATE tasks SET title=?, description=?, assignee_id=?, status=?, priority=?, due_date=?, dependency_task_id=?, updated_at=?
    WHERE task_id=?
  `).bind(updated.title, updated.description, updated.assignee_id, updated.status, updated.priority, updated.due_date, updated.dependency_task_id, now(), taskId).run()

  // 담당자 변경 로그
  if (body.assignee_id !== undefined && body.assignee_id !== existing.assignee_id) {
    await logActivity(db, { entityType: 'task', entityId: taskId, action: 'assign', before: { assignee_id: existing.assignee_id }, after: { assignee_id: body.assignee_id }, actedBy: userId })
  }
  // 상태 변경 로그
  if (body.status && body.status !== existing.status) {
    await logActivity(db, { entityType: 'task', entityId: taskId, action: 'status_change', before: { status: existing.status }, after: { status: body.status }, actedBy: userId })
  }
  // 마감일 변경 로그
  if (body.due_date !== undefined && body.due_date !== existing.due_date) {
    await logActivity(db, { entityType: 'task', entityId: taskId, action: 'change_due_date', before: { due_date: existing.due_date }, after: { due_date: body.due_date }, actedBy: userId })
  }
  // 일반 수정 로그
  await logActivity(db, { entityType: 'task', entityId: taskId, action: 'update', before: existing, after: updated, actedBy: userId })

  // 자동 일정 업데이트
  if (body.due_date !== undefined) {
    await autoCreateSchedule(db, { task_id: taskId, title: updated.title, due_date: updated.due_date, assignee_id: updated.assignee_id }, userId)
  }

  const task = await db.prepare(`
    SELECT t.*, u_a.name as assignee_name, u_a.avatar_color as assignee_color
    FROM tasks t LEFT JOIN users u_a ON t.assignee_id = u_a.user_id
    WHERE t.task_id = ?
  `).bind(taskId).first<any>()
  
  task.is_delayed = isDelayed(task.due_date, task.status) ? 1 : 0
  return c.json({ task })
})

// DELETE /api/tasks/:id (소프트 삭제)
tasks.delete('/:id', async (c) => {
  const taskId = c.req.param('id')
  const db = c.env.DB
  const userId = c.get('userId')
  
  const existing = await db.prepare('SELECT task_id FROM tasks WHERE task_id = ? AND deleted_at IS NULL').bind(taskId).first<any>()
  if (!existing) return c.json({ error: '업무를 찾을 수 없습니다.' }, 404)

  await db.prepare('UPDATE tasks SET deleted_at = ?, updated_at = ? WHERE task_id = ?').bind(now(), now(), taskId).run()
  
  await logActivity(db, { entityType: 'task', entityId: taskId, action: 'delete', actedBy: userId })
  
  return c.json({ success: true })
})

// PATCH /api/tasks/:id/status
tasks.patch('/:id/status', async (c) => {
  const taskId = c.req.param('id')
  const db = c.env.DB
  const userId = c.get('userId')
  
  const body = await c.req.json().catch(() => null)
  if (!body?.status) return c.json({ error: 'status 값이 필요합니다.' }, 400)
  
  const validStatuses = ['To-do', 'In Progress', 'Done']
  if (!validStatuses.includes(body.status)) {
    return c.json({ error: '유효하지 않은 상태값입니다.' }, 400)
  }

  const existing = await db.prepare('SELECT * FROM tasks WHERE task_id = ? AND deleted_at IS NULL').bind(taskId).first<any>()
  if (!existing) return c.json({ error: '업무를 찾을 수 없습니다.' }, 404)

  await db.prepare('UPDATE tasks SET status = ?, updated_at = ? WHERE task_id = ?').bind(body.status, now(), taskId).run()
  
  await logActivity(db, { entityType: 'task', entityId: taskId, action: 'status_change', before: { status: existing.status }, after: { status: body.status }, actedBy: userId })
  
  return c.json({ success: true, status: body.status })
})

// PATCH /api/tasks/:id/assignee
tasks.patch('/:id/assignee', async (c) => {
  const taskId = c.req.param('id')
  const db = c.env.DB
  const userId = c.get('userId')
  
  const body = await c.req.json().catch(() => null)
  
  const existing = await db.prepare('SELECT * FROM tasks WHERE task_id = ? AND deleted_at IS NULL').bind(taskId).first<any>()
  if (!existing) return c.json({ error: '업무를 찾을 수 없습니다.' }, 404)

  await db.prepare('UPDATE tasks SET assignee_id = ?, updated_at = ? WHERE task_id = ?').bind(body?.assignee_id || null, now(), taskId).run()
  
  await logActivity(db, { entityType: 'task', entityId: taskId, action: 'assign', before: { assignee_id: existing.assignee_id }, after: { assignee_id: body?.assignee_id }, actedBy: userId })
  
  return c.json({ success: true })
})

// GET /api/tasks/:id/activity-logs
tasks.get('/:id/activity-logs', async (c) => {
  const db = c.env.DB
  const result = await db.prepare(`
    SELECT a.*, u.name as actor_name, u.avatar_color as actor_color
    FROM activity_logs a
    LEFT JOIN users u ON a.acted_by = u.user_id
    WHERE a.entity_type = 'task' AND a.entity_id = ?
    ORDER BY a.created_at DESC
    LIMIT 50
  `).bind(c.req.param('id')).all<any>()
  
  return c.json({ logs: result.results })
})

export default tasks
