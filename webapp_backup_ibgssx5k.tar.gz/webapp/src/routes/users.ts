// src/routes/users.ts
import { Hono } from 'hono'
import { authMiddleware } from '../middleware/auth'
import { generateId, now } from '../utils'
import type { Env, Variables } from '../middleware/auth'

const users = new Hono<{ Bindings: Env; Variables: Variables }>()

users.use('/*', authMiddleware)

const AVATAR_COLORS = [
  '#6366f1', '#ec4899', '#f59e0b', '#10b981', '#3b82f6',
  '#8b5cf6', '#ef4444', '#06b6d4', '#84cc16', '#f97316',
]

// GET /api/users
users.get('/', async (c) => {
  const db = c.env.DB
  const result = await db.prepare(
    'SELECT user_id, name, email, role, avatar_color, created_at FROM users ORDER BY created_at ASC'
  ).all<any>()
  return c.json({ users: result.results })
})

// GET /api/users/:id
users.get('/:id', async (c) => {
  const db = c.env.DB
  const user = await db.prepare(
    'SELECT user_id, name, email, role, avatar_color, created_at FROM users WHERE user_id = ?'
  ).bind(c.req.param('id')).first<any>()
  if (!user) return c.json({ error: '사용자를 찾을 수 없습니다.' }, 404)
  return c.json({ user })
})

// POST /api/users  (회원 추가)
users.post('/', async (c) => {
  const body = await c.req.json().catch(() => null)
  if (!body?.name?.trim()) return c.json({ error: '이름은 필수입니다.' }, 400)
  if (!body?.email?.trim()) return c.json({ error: '이메일은 필수입니다.' }, 400)

  const db = c.env.DB

  // 이메일 중복 체크
  const exists = await db.prepare('SELECT user_id FROM users WHERE email = ?').bind(body.email.trim()).first()
  if (exists) return c.json({ error: '이미 사용 중인 이메일입니다.' }, 409)

  // 자동 색상 지정
  const countResult = await db.prepare('SELECT COUNT(*) as cnt FROM users').first<{ cnt: number }>()
  const colorIdx = (countResult?.cnt ?? 0) % AVATAR_COLORS.length
  const avatarColor = body.avatar_color || AVATAR_COLORS[colorIdx]

  const userId = generateId()
  await db.prepare(`
    INSERT INTO users (user_id, name, email, password_hash, role, avatar_color, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    userId,
    body.name.trim(),
    body.email.trim().toLowerCase(),
    'no-auth', // 로그인 없음
    body.role || 'Member',
    avatarColor,
    now(), now()
  ).run()

  const user = await db.prepare(
    'SELECT user_id, name, email, role, avatar_color, created_at FROM users WHERE user_id = ?'
  ).bind(userId).first<any>()

  return c.json({ user }, 201)
})

// PUT /api/users/:id  (회원 수정)
users.put('/:id', async (c) => {
  const userId = c.req.param('id')
  const db = c.env.DB

  const existing = await db.prepare('SELECT * FROM users WHERE user_id = ?').bind(userId).first<any>()
  if (!existing) return c.json({ error: '사용자를 찾을 수 없습니다.' }, 404)

  const body = await c.req.json().catch(() => null)
  if (!body) return c.json({ error: '유효하지 않은 요청입니다.' }, 400)
  if (body.name !== undefined && !body.name?.trim()) return c.json({ error: '이름은 필수입니다.' }, 400)

  // 이메일 중복 체크 (자신 제외)
  if (body.email && body.email.trim().toLowerCase() !== existing.email) {
    const dup = await db.prepare('SELECT user_id FROM users WHERE email = ? AND user_id != ?')
      .bind(body.email.trim().toLowerCase(), userId).first()
    if (dup) return c.json({ error: '이미 사용 중인 이메일입니다.' }, 409)
  }

  await db.prepare(`
    UPDATE users SET name=?, email=?, role=?, avatar_color=?, updated_at=? WHERE user_id=?
  `).bind(
    body.name?.trim() ?? existing.name,
    body.email?.trim().toLowerCase() ?? existing.email,
    body.role ?? existing.role,
    body.avatar_color ?? existing.avatar_color,
    now(), userId
  ).run()

  const user = await db.prepare(
    'SELECT user_id, name, email, role, avatar_color, created_at FROM users WHERE user_id = ?'
  ).bind(userId).first<any>()

  return c.json({ user })
})

// DELETE /api/users/:id  (회원 삭제)
users.delete('/:id', async (c) => {
  const userId = c.req.param('id')
  const db = c.env.DB

  const existing = await db.prepare('SELECT user_id FROM users WHERE user_id = ?').bind(userId).first()
  if (!existing) return c.json({ error: '사용자를 찾을 수 없습니다.' }, 404)

  // 총 인원이 1명이면 삭제 불가
  const countResult = await db.prepare('SELECT COUNT(*) as cnt FROM users').first<{ cnt: number }>()
  if ((countResult?.cnt ?? 0) <= 1) {
    return c.json({ error: '마지막 팀원은 삭제할 수 없습니다.' }, 400)
  }

  // 담당 업무/일정/이슈는 null 처리
  await db.batch([
    db.prepare('UPDATE tasks SET assignee_id = NULL WHERE assignee_id = ?').bind(userId),
    db.prepare('UPDATE schedules SET owner_id = NULL WHERE owner_id = ?').bind(userId),
    db.prepare('DELETE FROM sessions WHERE user_id = ?').bind(userId),
    db.prepare('DELETE FROM users WHERE user_id = ?').bind(userId),
  ])

  return c.json({ success: true })
})

export default users
