// src/utils.ts
export function generateId(): string {
  return crypto.randomUUID()
}

export function hashPassword(password: string): string {
  // 간단한 해시 (실제 운영에서는 bcrypt 등 사용)
  // Cloudflare Workers 환경에서는 Web Crypto API 사용
  let hash = 0
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i)
    hash = ((hash << 5) - hash) + char
    hash = hash & hash
  }
  return Math.abs(hash).toString(16).padStart(8, '0')
}

export function now(): string {
  return new Date().toISOString().replace('T', ' ').substring(0, 19)
}

export function isDelayed(dueDate: string | null, status: string): boolean {
  if (!dueDate || status === 'Done') return false
  return new Date() > new Date(dueDate)
}

export function jsonSafe(val: any): string {
  try {
    return JSON.stringify(val)
  } catch {
    return '{}'
  }
}
