// src/middleware/auth.ts
// 로그인 기능 제거 - 모든 요청 허용 (인증 없음)
import { Context, Next } from 'hono'

export type Env = {
  DB: D1Database
}

export type Variables = {
  userId: string
  userName: string
  userRole: string
}

// 인증 없이 항상 통과 - 첫 번째 사용자를 기본 사용자로 사용
export async function authMiddleware(c: Context<{ Bindings: Env; Variables: Variables }>, next: Next) {
  const db = c.env.DB
  
  // 요청 헤더에서 사용자 ID 확인 (프론트엔드에서 X-User-Id 헤더로 전송)
  const headerUserId = c.req.header('X-User-Id')
  
  if (headerUserId) {
    const user = await db.prepare(
      'SELECT user_id, name, role FROM users WHERE user_id = ?'
    ).bind(headerUserId).first<{ user_id: string; name: string; role: string }>()
    
    if (user) {
      c.set('userId', user.user_id)
      c.set('userName', user.name)
      c.set('userRole', user.role)
      await next()
      return
    }
  }

  // 헤더가 없으면 첫 번째 사용자 사용
  const firstUser = await db.prepare(
    'SELECT user_id, name, role FROM users ORDER BY created_at LIMIT 1'
  ).first<{ user_id: string; name: string; role: string }>()

  if (firstUser) {
    c.set('userId', firstUser.user_id)
    c.set('userName', firstUser.name)
    c.set('userRole', firstUser.role)
  } else {
    // 사용자가 아직 없을 경우 임시값
    c.set('userId', 'system')
    c.set('userName', '시스템')
    c.set('userRole', 'Admin')
  }

  await next()
}
