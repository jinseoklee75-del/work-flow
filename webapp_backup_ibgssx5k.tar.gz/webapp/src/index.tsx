// src/index.tsx
import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'
import auth from './routes/auth'
import users from './routes/users'
import tasks from './routes/tasks'
import schedules from './routes/schedules'
import issues from './routes/issues'
import comments from './routes/comments'
import attachments from './routes/attachments'
import dashboard from './routes/dashboard'

type Bindings = {
  DB: D1Database
}

const app = new Hono<{ Bindings: Bindings }>()

// CORS 설정
app.use('/api/*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization', 'Cookie', 'X-User-Id'],
  credentials: true,
}))

// API 라우트
app.route('/api/auth', auth)
app.route('/api/users', users)
app.route('/api/tasks', tasks)
app.route('/api/schedules', schedules)
app.route('/api/issues', issues)
app.route('/api', comments)
app.route('/api', attachments)
app.route('/api/dashboard', dashboard)

// 정적 파일 서빙
app.use('/static/*', serveStatic({ root: './' }))

// SPA 폴백 - 모든 요청을 index.html로
app.get('*', async (c) => {
  // API 요청이 아닌 경우 SPA 페이지 반환
  const path = c.req.path
  if (path.startsWith('/api/')) {
    return c.json({ error: 'Not Found' }, 404)
  }
  
  return c.html(getHtmlApp())
})

function getHtmlApp(): string {
  return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TeamFlow - 통합 업무공유 시스템</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/dayjs@1.11.10/dayjs.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/dayjs@1.11.10/locale/ko.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <link rel="stylesheet" href="/static/styles.css">
</head>
<body class="bg-gray-50 text-gray-900">
  <div id="app"></div>
  <script src="/static/app.js"></script>
</body>
</html>`
}

export default app
